import 'package:flutter/material.dart';

// 定義交易類型 (支出或收入)
enum TransactionType {
  expense,
  income,
}

// 定義一筆交易的資料結構
class Transaction {
  final String id;
  final String note;          // 備註 (例如：迷克夏)
  final double amount;        // 金額
  final DateTime date;        // 時間
  final String category;      // 分類 (例如：飲食)
  final IconData categoryIcon; // 分類圖示 (暫時用)
  final TransactionType type; // 類型

  Transaction({
    required this.id,
    required this.note,
    required this.amount,
    required this.date,
    required this.category,
    required this.categoryIcon,
    required this.type,
  });
}