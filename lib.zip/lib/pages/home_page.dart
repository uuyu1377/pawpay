import 'package:flutter/material.dart';
import 'package:user_interface/models/transaction_model.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:async';
import 'dart:math' as math;

// ★★★ 來自合併：需要引入 DatabaseHelper 才能讀取解鎖分類
import 'package:user_interface/services/database_helper.dart';

// 引入語音頁面
import 'package:user_interface/pages/voice_page.dart';

class HomePage extends StatefulWidget {
  final List<Transaction> transactions;
  // 給外部 (MainAppShell) 呼叫用，通知它要處理 AI 分析
  final Function(String)? onAiAnalyzeRequest;

  // ★★★ 新增：刪除與編輯的回呼函式 (預留給 MainAppShell 接上資料庫使用) ★★★
  final Function(String id)? onDeleteTransaction;
  final Function(Transaction tx)? onEditTransaction;

  const HomePage({
    super.key,
    required this.transactions,
    this.onAiAnalyzeRequest, // 接收外部傳入的處理函式
    this.onDeleteTransaction, // ★★★ 新增 ★★★
    this.onEditTransaction,   // ★★★ 新增 ★★★
  });

  @override
  HomePageState createState() => HomePageState();
}

class HomePageState extends State<HomePage> {
  DateTime _selectedDate = DateTime.now();

  // AI 短評相關狀態 (保留你的邏輯)
  String? _aiComment;
  bool _showAiComment = false;
  Timer? _timer;

  // ★★★ 來自合併：動態分類相關變數 ★★★
  static const int _catsPerPage = 4;
  final PageController _catPageController = PageController();
  int _catPageIndex = 0;
  late Future<List<Map<String, dynamic>>> _quickExpenseFuture;

  // ★★★ 新增：自訂圖示快取對照表 (讓房子下面也能顯示自創圖示) ★★★
  final Map<String, String> _categoryIconKeys = {};

  // ★★★ 新增：圖示翻譯蒟蒻 (與 TypePage 保持一致) ★★★
  final Map<String, IconData> _selectableIcons = {
    'star': Icons.star_rounded,
    'favorite': Icons.favorite_rounded,
    'shopping_cart': Icons.shopping_cart_rounded,
    'local_mall': Icons.local_mall_rounded,
    'card_giftcard': Icons.card_giftcard_rounded,
    'redeem': Icons.redeem_rounded,
    'fastfood': Icons.fastfood_rounded,
    'local_cafe': Icons.local_cafe_rounded,
    'restaurant': Icons.restaurant_rounded,
    'icecream': Icons.icecream_rounded,
    'directions_car': Icons.directions_car_rounded,
    'train': Icons.train_rounded,
    'flight': Icons.flight_rounded,
    'local_gas_station': Icons.local_gas_station_rounded,
    'two_wheeler': Icons.two_wheeler_rounded,
    'medical_services': Icons.medical_services_rounded,
    'fitness_center': Icons.fitness_center_rounded,
    'pets': Icons.pets_rounded,
    'home': Icons.home_rounded,
    'chair': Icons.chair_rounded,
    'cleaning_services': Icons.cleaning_services_rounded,
    'sports_esports': Icons.sports_esports_rounded,
    'movie': Icons.movie_rounded,
    'music_note': Icons.music_note_rounded,
    'palette': Icons.palette_rounded,
    'camera_alt': Icons.camera_alt_rounded,
    'school': Icons.school_rounded,
    'menu_book': Icons.menu_book_rounded,
    'laptop_mac': Icons.laptop_mac_rounded,
    'phone_iphone': Icons.phone_iphone_rounded,
    'work': Icons.work_rounded,
    'attach_money': Icons.attach_money_rounded,
    'savings': Icons.savings_rounded,
    'account_balance': Icons.account_balance_rounded,
    'groups': Icons.groups_rounded,
    'bolt': Icons.bolt_rounded,
    'lightbulb': Icons.lightbulb_rounded,
    'child_friendly': Icons.child_friendly_rounded,
  };

  // ★ 城市建築：目前使用者身分代碼（Onboarding 存在 SharedPreferences: user_identity）
  String _identityCode = 'u23'; // u23 / a23_35 / a35p

  String get _identityGroup {
    if (_identityCode == 'a23_35') return 'worker';
    if (_identityCode == 'a35p') return 'family';
    return 'student';
  }

  Future<void> _loadIdentity() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final code = prefs.getString('user_identity') ?? 'u23';
      if (!mounted) return;
      setState(() {
        _identityCode = code;
      });
    } catch (_) {
      // 讀取失敗就用預設 student
    }
  }

  @override
  void initState() {
    super.initState();
    // ★★★ 來自合併：初始化讀取分類
    _quickExpenseFuture = _loadQuickExpense();
    _loadIdentity();
  }

  // ★★★ 來自合併：當交易更新時，重新讀取分類 (因為可能剛解鎖新分類)
  @override
  void didUpdateWidget(covariant HomePage oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.transactions.length != widget.transactions.length) {
      setState(() {
        _quickExpenseFuture = _loadQuickExpense();
        _loadIdentity();
        _catPageIndex = 0;
        if (_catPageController.hasClients) {
          _catPageController.jumpToPage(0);
        }
      });
    }
  }

  // ★★★ 來自合併：讀取資料庫分類
  Future<List<Map<String, dynamic>>> _loadQuickExpense() {
    return DatabaseHelper.instance.getQuickCategories(type: 'expense');
  }

  // 給外部 (MainAppShell) 呼叫：顯示 AI 短評
  void showAiComment(String comment) {
    triggerAiComment(comment);
  }

  // 給外部呼叫的方法，用來觸發 AI 短評動畫 (保留你的邏輯)
  void triggerAiComment(String comment) {
    setState(() {
      _aiComment = comment;
      _showAiComment = true;
    });

    // 8秒後自動消失
    _timer?.cancel();
    _timer = Timer(const Duration(seconds: 8), () {
      if (mounted) {
        setState(() {
          _showAiComment = false;
        });
      }
    });
  }

  // 處理語音按鈕點擊 (保留你的邏輯)
  void _onVoiceButtonPressed() async {
    final result = await Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => const VoicePage()),
    );

    if (result != null && result is Map && result['type'] == 'voice_input') {
      String text = result['text'];
      print("🎤 收到語音文字: $text");

      if (widget.onAiAnalyzeRequest != null) {
        widget.onAiAnalyzeRequest!(text);
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("收到語音：$text (等待連接 AI)")),
        );
      }
    }
  }

  @override
  void dispose() {
    _timer?.cancel();
    _catPageController.dispose();
    super.dispose();
  }

  void _presentDatePicker() async {
    final now = DateTime.now();
    final pickedDate = await showDatePicker(
      context: context,
      initialDate: _selectedDate,
      firstDate: DateTime(now.year - 1),
      lastDate: now,
    );
    if (pickedDate != null && pickedDate != _selectedDate) {
      setState(() {
        _selectedDate = pickedDate;
      });
    }
  }

  Widget _buildDateHeader(String date) {
    return Padding(
      padding: const EdgeInsets.only(top: 16.0, bottom: 8.0, left: 16.0),
      child: Text(
        date,
        style: const TextStyle(
            fontSize: 16, fontWeight: FontWeight.bold, color: Colors.grey),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final monthlyTxs = widget.transactions.where((tx) {
      return tx.date.year == _selectedDate.year &&
          tx.date.month == _selectedDate.month;
    }).toList();

    double totalMonthIncome = monthlyTxs
        .where((tx) => tx.type == TransactionType.income)
        .fold(0.0, (sum, item) => sum + item.amount);

    double totalMonthExpense = monthlyTxs
        .where((tx) => tx.type == TransactionType.expense)
        .fold(0.0, (sum, item) => sum + item.amount);

    final selectedDay =
    DateTime(_selectedDate.year, _selectedDate.month, _selectedDate.day);

    final filteredTxs = widget.transactions.where((tx) {
      final txDay = DateTime(tx.date.year, tx.date.month, tx.date.day);
      return !txDay.isAfter(selectedDay);
    }).toList();

    filteredTxs.sort((a, b) => b.date.compareTo(a.date));

    List<Widget> groupedListWidgets = [];
    String? lastDateHeader;

    for (var tx in filteredTxs) {
      String txDateString = DateFormat('yyyy / MM / dd').format(tx.date);
      if (txDateString != lastDateHeader) {
        groupedListWidgets.add(_buildDateHeader(txDateString));
        lastDateHeader = txDateString;
      }

      // ★★★ 修改：將整個 tx 物件傳給 _buildTransactionItem ★★★
      groupedListWidgets.add(_buildTransactionItem(
        tx,
        '${tx.type == TransactionType.expense ? '-' : '+'} \$${tx.amount.toStringAsFixed(0)}',
        tx.type == TransactionType.expense ? Colors.red : Colors.green,
      ));
    }

    final double topPadding = MediaQuery.of(context).padding.top;

    return Stack(
      children: [
        // 1. 原本的頁面內容
        SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                padding: EdgeInsets.only(
                    top: topPadding + 16.0, left: 16, right: 16),
                child: _buildHeader(totalMonthIncome, totalMonthExpense),
              ),
              const SizedBox(height: 24),

              // ★★★ 這裡呼叫改寫後的分類區塊 ★★★
              _buildAccountSection(),

              const SizedBox(height: 24),
              if (groupedListWidgets.isEmpty)
                const Center(
                  child: Text(
                    '目前沒有交易紀錄',
                    style: TextStyle(color: Colors.grey, fontSize: 18),
                  ),
                )
              else
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: groupedListWidgets,
                ),
              // 底部留白給浮動按鈕
              const SizedBox(height: 100),
            ],
          ),
        ),

        // 2. 右下角浮動區塊 (保留你的邏輯)
        Positioned(
          right: 16,
          bottom: 16,
          child: Row(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              // (A) 對話框 (只在觸發時顯示)
              if (_showAiComment)
                Container(
                  margin: const EdgeInsets.only(right: 8, bottom: 10),
                  padding: const EdgeInsets.all(12),
                  constraints: const BoxConstraints(maxWidth: 220),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: const BorderRadius.only(
                      topLeft: Radius.circular(16),
                      topRight: Radius.circular(16),
                      bottomLeft: Radius.circular(16),
                      bottomRight: Radius.circular(4),
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.15),
                        blurRadius: 8,
                        offset: const Offset(0, 4),
                      )
                    ],
                  ),
                  child: Text(
                    _aiComment ?? "",
                    style: const TextStyle(fontSize: 14, color: Colors.black87),
                  ),
                ),

              // (B) 搜尋/動物按鈕
              FloatingActionButton(
                heroTag: "search_btn",
                onPressed: () {
                  if (_showAiComment) {
                    setState(() => _showAiComment = false);
                  } else {
                    showSearch(
                      context: context,
                      delegate: TransactionSearchDelegate(widget.transactions),
                    );
                  }
                },
                backgroundColor: _showAiComment ? const Color(0xFFFFF59D) : Colors.blueAccent,
                child: _showAiComment
                    ? const Text("🦜", style: TextStyle(fontSize: 32))
                    : const Icon(Icons.search, color: Colors.white),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildHeader(double totalMonthIncome, double totalMonthExpense) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
      decoration: BoxDecoration(
        color: Colors.grey[100],
        borderRadius: BorderRadius.circular(20),
      ),
      child: Column(
        children: [
          InkWell(
            onTap: _presentDatePicker,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  DateFormat('yyyy / MM 月').format(_selectedDate),
                  style: const TextStyle(
                      fontSize: 16,
                      color: Colors.grey,
                      fontWeight: FontWeight.bold),
                ),
                const Icon(Icons.arrow_drop_down, color: Colors.grey),
              ],
            ),
          ),
          const SizedBox(height: 16),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              _buildIncomeExpense('收入',
                  '+ \$${totalMonthIncome.toStringAsFixed(0)}', Colors.green),
              _buildIncomeExpense('支出',
                  '- \$${totalMonthExpense.toStringAsFixed(0)}', Colors.red),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildIncomeExpense(String label, String amount, Color color) {
    return Column(
      children: [
        Text(label, style: const TextStyle(fontSize: 14, color: Colors.grey)),
        const SizedBox(height: 4),
        SizedBox(
          width: 120, // 防止金額過長造成 overflow
          child: FittedBox(
            fit: BoxFit.scaleDown,
            child: Text(
              amount,
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
                color: color,
              ),
              maxLines: 1,
            ),
          ),
        ),
      ],
    );
  }

  // ★★★ 來自合併：這裡整個替換成朋友的邏輯 (Database + PageView) ★★★
  Widget _buildAccountSection() {
    // 這一排「城市地塊」：顯示首頁可用的分類（通用+身分+已解鎖），並依本月金額由高到低排序
    final selectedMonth = DateTime(_selectedDate.year, _selectedDate.month, 1);
    final monthlyTxs = widget.transactions.where((tx) {
      return tx.date.year == _selectedDate.year && tx.date.month == _selectedDate.month;
    }).toList();

    // 只蓋「主類」：先抓出（通用 + 身分）主類名單
    final mainNames = DatabaseHelper.instance.getMainNamesForType('expense');
    final mainSet = mainNames.toSet();

    // 身分影響「升級門檻」：用身分預設 + 近期資料動態估計一個 budgetScale
    final budgetScale = _computeBudgetScale(
      selectedMonth: selectedMonth,
      allTxs: widget.transactions,
      identityGroup: _identityGroup,
    );

    return FutureBuilder<List<Map<String, dynamic>>>(
      future: _quickExpenseFuture,
      builder: (context, snap) {
        if (snap.connectionState != ConnectionState.done) {
          // 載入中
          return const SizedBox(height: 140, child: Center(child: CircularProgressIndicator()));
        }
        if (snap.hasError) {
          // 錯誤處理
          return SizedBox(
            height: 140,
            child: Center(
              child: Text(
                '分類載入失敗\n請嘗試重啟 App',
                textAlign: TextAlign.center,
                style: const TextStyle(color: Colors.grey),
              ),
            ),
          );
        }

        final rowsAll = snap.data ?? const [];
        if (rowsAll.isEmpty) {
          return const SizedBox(
            height: 140,
            child: Center(
              child: Text('尚無可顯示分類', style: TextStyle(color: Colors.grey)),
            ),
          );
        }

        // ★★★ 新增：將撈出來的自訂圖示寫入快取字典 ★★★
        for (var row in rowsAll) {
          if (row['icon_key'] != null && row['icon_key'].toString().isNotEmpty) {
            _categoryIconKeys[row['name'].toString()] = row['icon_key'].toString();
          }
        }

        // ★★★ 【第三站：首頁營造廠的 VIP 名單查詢處】 ★★★
        // 改良：直接利用資料庫的 is_custom 欄位，精準抓出「自創/AI生成」的分類
        final customMainSet = rowsAll
            .where((e) => (e['is_custom'] as int? ?? 0) == 1)
            .map((e) => (e['name'] ?? '').toString())
            .toSet();

        // 幫所有的交易紀錄找家
        final expenseTotals = <String, double>{};
        for (final tx in monthlyTxs) {
          if (tx.type != TransactionType.expense) continue;
          // 傳入 customMainSet 作為判斷依據
          final main = _inferMainExpense(tx.category, mainSet, customMainSet);
          expenseTotals[main] = (expenseTotals[main] ?? 0) + tx.amount;
        }

        // 轉成可排序/可修改的 list（★智慧過濾法：只蓋獨立的自創大樓和主類大樓！）
        final rows = rowsAll
            .map((e) => Map<String, dynamic>.from(e))
            .where((row) {
          final name = (row['name'] ?? '').toString();
          // 這樣「手續費(is_custom=0)」會被濾掉，而「自創詞(is_custom=1)」會被保留！
          return _inferMainExpense(name, mainSet, customMainSet) == name;
        })
            .toList();

        // 用「原本順序」當作 tie-breaker，避免同分一直跳動
        final originalIndex = <String, int>{};
        for (int i = 0; i < rows.length; i++) {
          final name = (rows[i]['name'] ?? '').toString();
          if (name.isEmpty) continue;
          originalIndex.putIfAbsent(name, () => i);
        }

        // 只拿「首頁顯示的分類」去算 maxAmount，確保相對高度更直觀
        final maxAmount = rows.fold<double>(0.0, (m, row) {
          final name = (row['name'] ?? '').toString();
          final a = expenseTotals[name] ?? 0.0;
          return math.max(m, a);
        });

        // 依本月建築高度(=金額)由高到低排序：tier -> floors -> amount -> 原本順序
        rows.sort((a, b) {
          final na = (a['name'] ?? '').toString();
          final nb = (b['name'] ?? '').toString();

          final aa = expenseTotals[na] ?? 0.0;
          final ab = expenseTotals[nb] ?? 0.0;

          final sa = _heightScore(
            amount: aa,
            maxAmount: maxAmount,
            budgetScale: budgetScale,
            identityGroup: _identityGroup,
          );
          final sb = _heightScore(
            amount: ab,
            maxAmount: maxAmount,
            budgetScale: budgetScale,
            identityGroup: _identityGroup,
          );

          if (sa != sb) return sb.compareTo(sa);
          if (aa != ab) return ab.compareTo(aa);

          final ia = originalIndex[na] ?? 0;
          final ib = originalIndex[nb] ?? 0;
          if (ia != ib) return ia.compareTo(ib);

          return na.compareTo(nb);
        });

        final pageCount = (rows.length / _catsPerPage).ceil().clamp(1, 999);

        // 每頁最多 4 個地塊
        return Column(
          children: [
            SizedBox(
              height: 152,
              child: PageView.builder(
                controller: _catPageController,
                itemCount: pageCount,
                onPageChanged: (i) => setState(() => _catPageIndex = i),
                itemBuilder: (context, pageIndex) {
                  final start = pageIndex * _catsPerPage;
                  final end = (start + _catsPerPage).clamp(0, rows.length);
                  final pageItems = rows.sublist(start, end);

                  // 排版填充：不足 4 個補空位，確保間距一致
                  while (pageItems.length < _catsPerPage) {
                    pageItems.add({'name': '', 'is_placeholder': 1});
                  }

                  return Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: pageItems.map((row) {
                        final name = (row['name'] ?? '').toString();
                        if (name.isEmpty) {
                          return const SizedBox(width: 82);
                        }
                        final amount = expenseTotals[name] ?? 0.0;
                        return _buildCategoryIcon(
                          name,
                          amount: amount,
                          maxAmount: maxAmount,
                          budgetScale: budgetScale,
                        );
                      }).toList(),
                    ),
                  );
                },
              ),
            ),
            // 分頁指示點點
            const SizedBox(height: 6),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: List.generate(pageCount, (i) {
                final isActive = i == _catPageIndex;
                return AnimatedContainer(
                  duration: const Duration(milliseconds: 180),
                  margin: const EdgeInsets.symmetric(horizontal: 3),
                  width: isActive ? 10 : 6,
                  height: 6,
                  decoration: BoxDecoration(
                    color: isActive ? Colors.blueAccent : Colors.grey[300],
                    borderRadius: BorderRadius.circular(99),
                  ),
                );
              }),
            ),
          ],
        );
      },
    );
  }


  // 城市化分類地塊：用「建築高度」呈現本月該分類金額
  Widget _buildCategoryIcon(
      String label, {
        required double amount,
        required double maxAmount,
        required double budgetScale,
      }) {
    final baseColor = _colorForCategory(label);

    // Tier（外觀）由「絕對金額/門檻」決定；floors（細節高度）由「相對比例」決定
    final tier = _tierForAmount(
      amount: amount,
      budgetScale: budgetScale,
      identityGroup: _identityGroup,
    );
    final floors = _floorsForAmount(amount: amount, maxAmount: maxAmount);

    final buildingH = _buildingHeight(tier: tier, floors: floors);
    final buildingW = _buildingWidth(tier: tier);

    final tip = '本月$label：${_fmtMoney(amount)}';

    return Tooltip(
      message: tip,
      triggerMode: TooltipTriggerMode.longPress,
      waitDuration: const Duration(milliseconds: 250),
      showDuration: const Duration(seconds: 2),
      child: InkWell(
        key: ValueKey('citycat_$label'),
        borderRadius: BorderRadius.circular(18),
        onTap: () {
          // 目前行為：點地塊可以在這裡做篩選或其他動作（暫時留空，避免動到既有功能）
        },
        child: SizedBox(
          width: 82,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                height: 96,
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: baseColor.withOpacity(0.10),
                  borderRadius: BorderRadius.circular(18),
                ),
                child: Stack(
                  children: [
                    Align(
                      alignment: Alignment.bottomCenter,
                      child: _buildCityLot(
                        tier: tier,
                        floors: floors,
                        baseColor: baseColor,
                        buildingHeight: buildingH,
                        buildingWidth: buildingW,
                      ),
                    ),
                    // 右上角保留原本 icon 的辨識度（不影響城市主視覺）
                    Positioned(
                      top: 0,
                      right: 0,
                      child: Container(
                        padding: const EdgeInsets.all(4),
                        decoration: BoxDecoration(
                          color: Colors.white.withOpacity(0.85),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Icon(
                          _iconForCategory(label),
                          size: 14,
                          color: baseColor,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 6),
              Text(
                label,
                style: const TextStyle(fontSize: 12),
                textAlign: TextAlign.center,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildCityLot({
    required _BuildingTier tier,
    required int floors,
    required Color baseColor,
    required double buildingHeight,
    required double buildingWidth,
  }) {
    // 地面（道路/草地）
    final lot = Container(
      height: 10,
      width: 64,
      decoration: BoxDecoration(
        color: baseColor.withOpacity(0.18),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Align(
        alignment: Alignment.center,
        child: Container(
          height: 2,
          width: 42,
          decoration: BoxDecoration(
            color: Colors.white.withOpacity(0.55),
            borderRadius: BorderRadius.circular(99),
          ),
        ),
      ),
    );

    if (tier == _BuildingTier.empty) {
      // 沒花錢：留空地塊（放一棵小樹）
      return Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            height: 22,
            width: 22,
            decoration: BoxDecoration(
              color: baseColor.withOpacity(0.22),
              shape: BoxShape.circle,
            ),
            child: Icon(Icons.park, size: 14, color: baseColor.withOpacity(0.9)),
          ),
          const SizedBox(height: 4),
          lot,
        ],
      );
    }

    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        // 建築本體：新增交易後會因為 amount 變動而「長高一下」
        AnimatedContainer(
          duration: const Duration(milliseconds: 420),
          curve: Curves.easeOutBack,
          height: buildingHeight,
          width: buildingWidth,
          child: AnimatedSwitcher(
            duration: const Duration(milliseconds: 220),
            switchInCurve: Curves.easeOut,
            switchOutCurve: Curves.easeIn,
            child: _buildBuildingBody(
              key: ValueKey(tier),
              tier: tier,
              floors: floors,
              color: baseColor,
            ),
          ),
        ),
        const SizedBox(height: 4),
        lot,
      ],
    );
  }

  Widget _buildBuildingBody({
    required Key key,
    required _BuildingTier tier,
    required int floors,
    required Color color,
  }) {
    final bodyColor = Color.lerp(color, Colors.black, 0.12) ?? color;
    final windowColor = Colors.white.withOpacity(0.70);

    // 依不同 tier 產生不同外觀：小屋 → 房子 → 公寓 → 大樓 → 摩天樓
    switch (tier) {
      case _BuildingTier.hut:
        return Stack(
          key: key,
          alignment: Alignment.bottomCenter,
          children: [
            Positioned(
              top: 0,
              child: ClipPath(
                clipper: _TriangleClipper(),
                child: Container(
                  width: 30,
                  height: 14,
                  color: color,
                ),
              ),
            ),
            Positioned(
              bottom: 0,
              child: ClipRRect(
                borderRadius: BorderRadius.circular(6),
                child: Container(
                  width: 30,
                  height: 18,
                  color: bodyColor,
                  child: Center(
                    child: Container(
                      width: 6,
                      height: 10,
                      decoration: BoxDecoration(
                        color: Colors.black.withOpacity(0.18),
                        borderRadius: BorderRadius.circular(2),
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ],
        );

      case _BuildingTier.house:
        return Stack(
          key: key,
          alignment: Alignment.bottomCenter,
          children: [
            Positioned(
              top: 0,
              child: ClipPath(
                clipper: _TriangleClipper(),
                child: Container(
                  width: 34,
                  height: 16,
                  color: color,
                ),
              ),
            ),
            Positioned(
              bottom: 0,
              child: ClipRRect(
                borderRadius: BorderRadius.circular(8),
                child: Container(
                  width: 34,
                  height: 26,
                  color: bodyColor,
                  child: Padding(
                    padding: const EdgeInsets.all(4),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        _window(windowColor),
                        _window(windowColor),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ],
        );

      case _BuildingTier.apartment:
        return _buildTower(
          key: key,
          width: 30,
          color: bodyColor,
          topColor: color,
          rows: math.max(2, floors),
          cols: 3,
          windowColor: windowColor,
          hasTopLedge: true,
        );

      case _BuildingTier.highrise:
        return _buildTower(
          key: key,
          width: 26,
          color: bodyColor,
          topColor: color,
          rows: math.max(3, floors + 1),
          cols: 2,
          windowColor: windowColor,
          hasTopLedge: true,
          hasSideAccent: true,
        );

      case _BuildingTier.skyscraper:
        return Stack(
          key: key,
          alignment: Alignment.bottomCenter,
          children: [
            // 尖塔
            Positioned(
              top: 0,
              child: Container(
                width: 6,
                height: 16,
                decoration: BoxDecoration(
                  color: color,
                  borderRadius: BorderRadius.circular(99),
                ),
              ),
            ),
            Positioned(
              top: 14,
              child: Container(
                width: 18,
                height: 6,
                decoration: BoxDecoration(
                  color: color,
                  borderRadius: BorderRadius.circular(6),
                ),
              ),
            ),
            Align(
              alignment: Alignment.bottomCenter,
              child: _buildTower(
                key: const ValueKey('tower'),
                width: 24,
                color: bodyColor,
                topColor: color,
                rows: math.max(4, floors + 2),
                cols: 2,
                windowColor: windowColor,
                hasTopLedge: true,
              ),
            ),
          ],
        );

      case _BuildingTier.empty:
      // 這裡不會走到
        return const SizedBox.shrink();
    }
  }

  Widget _buildTower({
    required Key key,
    required double width,
    required Color color,
    required Color topColor,
    required int rows,
    required int cols,
    required Color windowColor,
    bool hasTopLedge = false,
    bool hasSideAccent = false,
  }) {
    final accent = Color.lerp(color, Colors.black, 0.20) ?? color;

    return Stack(
      key: key,
      children: [
        ClipRRect(
          borderRadius: BorderRadius.circular(10),
          child: Container(
            width: width,
            color: color,
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 6),
              child: _windowGrid(rows: rows, cols: cols, color: windowColor),
            ),
          ),
        ),
        if (hasSideAccent)
          Positioned(
            left: 0,
            top: 0,
            bottom: 0,
            child: Container(
              width: 4,
              decoration: BoxDecoration(
                color: accent.withOpacity(0.45),
                borderRadius: const BorderRadius.horizontal(left: Radius.circular(10)),
              ),
            ),
          ),
        if (hasTopLedge)
          Positioned(
            top: 0,
            left: 0,
            right: 0,
            child: Container(
              height: 6,
              decoration: BoxDecoration(
                color: topColor.withOpacity(0.85),
                borderRadius: const BorderRadius.vertical(top: Radius.circular(10)),
              ),
            ),
          ),
      ],
    );
  }

  Widget _windowGrid({required int rows, required int cols, required Color color}) {
    final maxCells = math.min(rows * cols, 18); // 避免太多 widget
    final cells = <Widget>[];
    for (int i = 0; i < maxCells; i++) {
      cells.add(Container(
        width: 4,
        height: 6,
        margin: const EdgeInsets.all(1.2),
        decoration: BoxDecoration(
          color: color,
          borderRadius: BorderRadius.circular(2),
        ),
      ));
    }
    return Wrap(
      spacing: 0,
      runSpacing: 0,
      children: cells,
    );
  }

  Widget _window(Color color) {
    return Container(
      width: 6,
      height: 8,
      decoration: BoxDecoration(
        color: color,
        borderRadius: BorderRadius.circular(2),
      ),
    );
  }

  // ===== 建築規則（身分 / 交易金額 → 建築 tier & 高度） =====

  int _heightScore({
    required double amount,
    required double maxAmount,
    required double budgetScale,
    required String identityGroup,
  }) {
    final tier = _tierForAmount(amount: amount, budgetScale: budgetScale, identityGroup: identityGroup);
    final floors = _floorsForAmount(amount: amount, maxAmount: maxAmount);
    // tier 權重更高，避免「小屋 6 樓」排在「大樓 1 樓」前面
    return tier.index * 100 + floors;
  }

  _BuildingTier _tierForAmount({
    required double amount,
    required double budgetScale,
    required String identityGroup,
  }) {
    if (amount <= 0) return _BuildingTier.empty;

    // identityFactor：學生更容易升級、家庭稍微更難（因為通常金額較高）
    final identityFactor = identityGroup == 'student'
        ? 0.85
        : (identityGroup == 'family' ? 1.10 : 1.0);

    final scale = (budgetScale * identityFactor).clamp(3000.0, 200000.0);
    final ratio = amount / scale;

    // 小屋 → 房子 → 公寓 → 大樓 → 摩天樓
    if (ratio < 0.02) return _BuildingTier.hut;       // <2%
    if (ratio < 0.06) return _BuildingTier.house;     // 2%~6%
    if (ratio < 0.12) return _BuildingTier.apartment; // 6%~12%
    if (ratio < 0.20) return _BuildingTier.highrise;  // 12%~20%
    return _BuildingTier.skyscraper;                  // ≥20%
  }

  int _floorsForAmount({required double amount, required double maxAmount}) {
    if (amount <= 0 || maxAmount <= 0) return 0;
    // 相對比例：用本月最大值當 6 樓
    final raw = (amount / maxAmount) * 6;
    return raw.round().clamp(1, 6);
  }

  double _buildingHeight({required _BuildingTier tier, required int floors}) {
    if (tier == _BuildingTier.empty) return 0;
    final base = switch (tier) {
      _BuildingTier.hut => 26.0,
      _BuildingTier.house => 34.0,
      _BuildingTier.apartment => 44.0,
      _BuildingTier.highrise => 52.0,
      _BuildingTier.skyscraper => 60.0,
      _BuildingTier.empty => 0.0,
    };
    final unit = switch (tier) {
      _BuildingTier.hut => 1.5,
      _BuildingTier.house => 1.8,
      _BuildingTier.apartment => 2.0,
      _BuildingTier.highrise => 2.2,
      _BuildingTier.skyscraper => 2.4,
      _BuildingTier.empty => 0.0,
    };
    return (base + floors * unit).clamp(24.0, 66.0);
  }

  double _buildingWidth({required _BuildingTier tier}) {
    return switch (tier) {
      _BuildingTier.hut => 30.0,
      _BuildingTier.house => 34.0,
      _BuildingTier.apartment => 30.0,
      _BuildingTier.highrise => 26.0,
      _BuildingTier.skyscraper => 24.0,
      _BuildingTier.empty => 22.0,
    };
  }

  // ===== 身分門檻推估：用「近期花費」+「身分預設」估一個 budgetScale =====
  double _computeBudgetScale({
    required DateTime selectedMonth,
    required List<Transaction> allTxs,
    required String identityGroup,
  }) {
    final fallback = switch (identityGroup) {
      'student' => 12000.0,
      'family' => 70000.0,
      _ => 35000.0, // worker / default
    };

    double monthExpense(DateTime m) {
      return allTxs.where((tx) {
        return tx.type == TransactionType.expense && tx.date.year == m.year && tx.date.month == m.month;
      }).fold(0.0, (s, tx) => s + tx.amount);
    }

    double monthIncome(DateTime m) {
      return allTxs.where((tx) {
        return tx.type == TransactionType.income && tx.date.year == m.year && tx.date.month == m.month;
      }).fold(0.0, (s, tx) => s + tx.amount);
    }

    // 近三個月支出平均（有資料的月份才算）
    final months = [
      selectedMonth,
      DateTime(selectedMonth.year, selectedMonth.month - 1, 1),
      DateTime(selectedMonth.year, selectedMonth.month - 2, 1),
    ];
    final expVals = months.map(monthExpense).where((v) => v > 0).toList();
    final expAvg = expVals.isEmpty ? 0.0 : expVals.reduce((a, b) => a + b) / expVals.length;

    // 若本月有收入，拿收入估計「可接受的花費尺度」
    final inc = monthIncome(selectedMonth);
    final incFactor = identityGroup == 'student'
        ? 0.85
        : (identityGroup == 'family' ? 0.80 : 0.75);

    double base = expAvg;
    if (inc > 0) base = math.max(base, inc * incFactor);

    if (base <= 0) return fallback;

    // 混合身分預設，避免單月異常導致建築升級/降級太劇烈
    final blended = 0.70 * base + 0.30 * fallback;
    // 避免尺度太小/太大
    return blended.clamp(fallback * 0.6, fallback * 2.5);
  }

  // ===== 主類歸戶：把子類/自訂分類歸到某個主類，用來計算「主類建築高度」=====
  // ★★★ 修改：接收 customMainSet 來精準判斷是否為「自創主類」
  String _inferMainExpense(String name, Set<String> mainSet, Set<String> customMainSet) {
    // 1. 本身是內建主類 (例如: 飲食、交通) -> 直接獨立
    if (mainSet.contains(name)) return name;

    // 2. ★ 終極精準判斷：資料庫認證的自創分類 (is_custom == 1) -> 破例讓它獨立！
    if (customMainSet.contains(name)) return name;

    // 3. 剩下的一定是內建子類 (例如: 早餐、公車、手續費)，用字典乖乖幫它們歸戶
    String candidate = '其他支出';

    // 飲食
    if (name.contains('早餐') || name.contains('午餐') || name.contains('晚餐') ||
        name.contains('飲料') || name.contains('咖啡') || name.contains('宵夜') ||
        name.contains('零食') || name.contains('外送') || name.contains('聚餐')) {
      candidate = '飲食';
    }
    // 交通
    else if (name.contains('公車') || name.contains('捷運') || name.contains('火車') ||
        name.contains('高鐵') || name.contains('計程車') || name.contains('Uber') ||
        name.contains('加油') || name.contains('停車') || name.contains('維修')) {
      candidate = '交通';
    }
    // 生活用品
    else if (name.contains('超市') || name.contains('採買') || name.contains('衛生紙') ||
        name.contains('日用品') || name.contains('五金') || name.contains('百貨') ||
        name.contains('洗衣') || name.contains('清潔')) {
      candidate = '生活用品';
    }
    // 娛樂 / 社交
    else if (name.contains('電影') || name.contains('KTV') || name.contains('展覽') ||
        name.contains('表演') || name.contains('書') || name.contains('雜誌') ||
        name.contains('遊戲') || name.contains('串流')) {
      candidate = '娛樂';
    } else if (name.contains('請客') || name.contains('社交應酬') || name.contains('派對') || name.contains('送禮') || name.contains('禮物')) {
      candidate = '社交';
    }
    // 通訊網路 / 訂閱
    else if (name.contains('手機費') || name.contains('網路費')) {
      candidate = '通訊網路';
    } else if (name.contains('Netflix') || name.contains('Spotify') || name.contains('YouTube') ||
        name.contains('iCloud') || name.contains('Google Drive') || name.contains('Disney')) {
      candidate = '線上訂閱';
    }
    // 服飾美容
    else if (name.contains('衣') || name.contains('鞋') || name.contains('配件') ||
        name.contains('化妝') || name.contains('保養') || name.contains('剪髮') ||
        name.contains('美容') || name.contains('美甲') || name.contains('按摩')) {
      candidate = '服飾美容';
    }
    // 醫療健康
    else if (name.contains('看診') || name.contains('掛號') || name.contains('藥') ||
        name.contains('保健') || name.contains('健身') || name.contains('運動')) {
      candidate = '醫療健康';
    }
    // 住房
    else if (name.contains('房租') || name.contains('水電') || name.contains('瓦斯') || name.contains('管理費')) {
      candidate = '住房';
    }
    // 其他支出 (★補上手續費等)
    else if (name.contains('雜費') || name.contains('手續費') || name.contains('捐款') || name == '其他') {
      candidate = '其他支出';
    }
    // 學生
    else if (name.contains('學雜') || name.contains('參考書') || name.contains('課本') ||
        name.contains('補習') || name.contains('影印') || name.contains('文具')) {
      candidate = '學費與教材';
    } else if (name.contains('扭蛋') || name.contains('盲盒') || name.contains('公仔') || name.contains('周邊') || name.contains('課金')) {
      candidate = '小確幸';
    } else if (name.contains('生日') || name.contains('節日') || name.contains('伴手禮')) {
      candidate = '禮物與送禮';
    } else if (name.contains('遺失') || name.contains('弄丟') || name.contains('不見')) {
      candidate = '不見了';
    }
    // 上班族
    else if (name.contains('股票') || name.contains('基金') || name.contains('定期定額') || name.contains('扣款')) {
      candidate = '投資理財';
    } else if (name.contains('家具') || name.contains('家電') || name.contains('廚房') || name.contains('佈置')) {
      candidate = '家具家電';
    }
    // 家庭
    else if (name.contains('房貸') || name.contains('貸款') || name.contains('修繕') || name.contains('裝潢') || name.contains('房屋稅') || name.contains('地價稅')) {
      candidate = '房貸與修繕';
    } else if (name.contains('尿布') || name.contains('奶粉') || name.contains('安親') || name.contains('才藝') || name.contains('童書') || name.contains('玩具')) {
      candidate = '小孩教育';
    } else if (name.contains('保險') || name.contains('壽險') || name.contains('車險') || name.contains('儲蓄險') || name.contains('醫療險')) {
      candidate = '保險費用';
    } else if (name.contains('孝親') || name.contains('看護') || name.contains('長輩')) {
      candidate = '長輩支出';
    } else if (name.contains('機票') || name.contains('住宿') || name.contains('旅行團') || name.contains('旅遊')) {
      candidate = '家庭旅遊';
    }

    // 若這個候選主類本來就存在（依身分決定的主類清單），直接用
    if (mainSet.contains(candidate)) return candidate;

    // 若身分沒有某些「專屬主類」，就往更通用的主類歸戶
    const fallback = <String, List<String>>{
      '線上訂閱': ['娛樂', '通訊網路', '其他支出'],
      '小確幸': ['娛樂', '其他支出'],
      '禮物與送禮': ['社交', '其他支出'],
      '不見了': ['其他支出'],
      '投資理財': ['其他支出'],
      '家具家電': ['住房', '生活用品', '其他支出'],
      '房貸與修繕': ['住房', '其他支出'],
      '小孩教育': ['其他支出'],
      '保險費用': ['其他支出'],
      '長輩支出': ['其他支出'],
      '家庭旅遊': ['娛樂', '交通', '其他支出'],
      '學費與教材': ['其他支出'],
    };

    for (final fb in (fallback[candidate] ?? const <String>['其他支出'])) {
      if (mainSet.contains(fb)) return fb;
    }

    // 最後保底：回到「其他支出」或第一個主類
    if (mainSet.contains('其他支出')) return '其他支出';
    return mainSet.isNotEmpty ? mainSet.first : candidate;
  }

// ===== 顏色規則：常見主類給固定色，其餘用 hash 產生固定色 =====
  Color _colorForCategory(String label) {
    const fixed = {
      // 飲食
      '飲食': Colors.orange,
      '早餐': Colors.orange,
      '午餐': Colors.orange,
      '晚餐': Colors.orange,
      '宵夜': Colors.orange,
      '零食': Colors.orange,
      '外送': Colors.orange,
      '聚餐': Colors.orange,
      '飲料/咖啡': Colors.deepOrange,

      // 交通
      '交通': Colors.blue,
      '公車': Colors.blue,
      '捷運': Colors.blue,
      '火車/高鐵': Colors.indigo,
      '計程車/Uber': Colors.indigo,
      '加油': Colors.blueGrey,
      '停車費': Colors.blueGrey,
      '車輛維修': Colors.blueGrey,

      // 生活/住房
      '住房': Colors.brown,
      '房貸與修繕': Colors.brown,
      '水電瓦斯': Colors.brown,
      '房租': Colors.brown,
      '家具家電': Colors.brown,
      '生活用品': Colors.green,
      '超市採買': Colors.green,
      '衛生紙/日用品': Colors.green,
      '洗衣/清潔': Colors.green,
      '五金百貨': Colors.green,

      // 社交/娛樂
      '社交': Colors.purple,
      '請客': Colors.purple,
      '禮物與送禮': Colors.purple,
      '娛樂': Colors.pink,
      '小確幸': Colors.pink,
      '線上訂閱': Colors.pink,

      // 健康/美容
      '醫療健康': Colors.red,
      '服飾美容': Colors.teal,
      '剪髮/美容': Colors.teal,

      // 學生/工作/家庭
      '學費與教材': Colors.cyan,
      '投資理財': Colors.lightBlue,
      '小孩教育': Colors.cyan,

      // 其他
      '其他支出': Colors.grey,
      '不見了': Colors.grey,
    };

    if (fixed.containsKey(label)) return fixed[label]!;
    return _hashColor(label);
  }

  Color _hashColor(String s) {
    final palette = <Color>[
      Colors.orange,
      Colors.blue,
      Colors.green,
      Colors.purple,
      Colors.teal,
      Colors.indigo,
      Colors.red,
      Colors.brown,
      Colors.cyan,
      Colors.pink,
      Colors.blueGrey,
    ];
    int h = 0;
    for (final c in s.codeUnits) {
      h = ((h * 31) + c) & 0x7fffffff;
    }
    return palette[h % palette.length];
  }

  String _fmtMoney(double amount) {
    final nf = NumberFormat.decimalPattern();
    return '\$${nf.format(amount.round())}';
  }

  // ★★★ 核心修改：優先檢查 _categoryIconKeys 字典 ★★★
  IconData _iconForCategory(String name) {
    if (_categoryIconKeys.containsKey(name)) {
      final key = _categoryIconKeys[name];
      if (_selectableIcons.containsKey(key)) {
        return _selectableIcons[key]!;
      }
    }

    final n = name;

    // 主類
    if (n == '飲食') return Icons.fastfood_rounded;
    if (n == '交通') return Icons.directions_bus_rounded;
    if (n == '生活' || n == '生活用品') return Icons.cleaning_services_rounded;
    if (n == '社交') return Icons.groups_rounded;
    if (n == '娛樂') return Icons.sports_esports_rounded;
    if (n == '通訊網路') return Icons.wifi_rounded;
    if (n == '服飾' || n == '服飾美容') return Icons.checkroom_rounded;
    if (n == '醫療' || n == '醫療健康') return Icons.medical_services_rounded;
    if (n == '居家' || n == '住房') return Icons.home_rounded;
    if (n == '其他') return Icons.more_horiz_rounded;

    // 學生/學業
    if (n == '學業' || n == '學費與教材') return Icons.school_rounded;
    if (n == '興趣' || n == '線上訂閱') return Icons.subscriptions_rounded;
    if (n == '小確幸') return Icons.redeem_rounded;
    if (n == '禮物與送禮') return Icons.card_giftcard_rounded;

    // 上班族/理財
    if (n == '理財' || n == '投資理財') return Icons.trending_up_rounded;
    if (n == '家具家電') return Icons.chair_rounded;

    // 家庭
    if (n == '家庭' || n == '房貸與修繕') return Icons.house_rounded;
    if (n == '小孩教育') return Icons.child_care_rounded;
    if (n == '保險' || n == '保險費用') return Icons.verified_user_rounded;
    if (n == '長輩支出') return Icons.elderly_rounded;
    if (n == '家庭旅遊') return Icons.flight_rounded;

    // 常用子類匹配
    if (n.contains('早餐')) return Icons.bakery_dining_rounded;
    if (n.contains('午餐')) return Icons.rice_bowl_rounded;
    if (n.contains('晚餐')) return Icons.dinner_dining_rounded;
    if (n.contains('飲料') || n.contains('咖啡')) return Icons.local_cafe_rounded;
    if (n.contains('宵夜')) return Icons.nightlife_rounded;
    if (n.contains('零食')) return Icons.cookie_rounded;
    if (n.contains('外送')) return Icons.delivery_dining_rounded;
    if (n.contains('聚餐')) return Icons.restaurant_rounded;

    if (n.contains('公車') || n.contains('捷運') || n.contains('火車') || n.contains('高鐵')) return Icons.train_rounded;
    if (n.contains('計程車') || n.contains('Uber')) return Icons.local_taxi_rounded;
    if (n.contains('加油') || n.contains('停車') || n.contains('維修')) return Icons.local_gas_station_rounded;

    if (n.contains('超市') || n.contains('採買')) return Icons.shopping_cart_rounded;
    if (n.contains('日用品') || n.contains('衛生紙')) return Icons.local_mall_rounded;

    if (n.contains('電影') || n.contains('展覽') || n.contains('表演')) return Icons.movie_rounded;
    if (n.contains('KTV')) return Icons.mic_rounded;
    if (n.contains('遊戲') || n.contains('課金')) return Icons.sports_esports_rounded;
    if (n.contains('串流') || n.contains('Netflix') || n.contains('Spotify') || n.contains('YouTube')) {
      return Icons.subscriptions_rounded;
    }

    if (n.contains('手機費') || n.contains('網路費')) return Icons.wifi_rounded;
    if (n.contains('衣') || n.contains('鞋') || n.contains('配件')) return Icons.checkroom_rounded;
    if (n.contains('化妝') || n.contains('保養') || n.contains('剪髮')) {
      return Icons.face_retouching_natural_rounded;
    }

    if (n.contains('看診') || n.contains('掛號') || n.contains('藥') || n.contains('保健')) return Icons.medical_services_rounded;
    if (n.contains('房租') || n.contains('水電') || n.contains('瓦斯') || n.contains('管理費')) return Icons.home_rounded;

    return Icons.more_horiz_rounded;
  }

  // ★★★ 修改：將傳入的參數改為 Transaction 物件，並加上 Dismissible 滑動功能 ★★★
  Widget _buildTransactionItem(Transaction tx, String amountString, Color amountColor) {
    return Dismissible(
      // 必須給予唯一的 Key，Flutter 才能追蹤哪一個物件被滑動了
      key: ValueKey('tx_${tx.id}'),
      direction: DismissDirection.horizontal, // 允許左右滑動

      // ★ 右滑露出的背景 (編輯 - 綠色)
      background: Container(
        margin: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 4.0),
        decoration: BoxDecoration(
          color: Colors.green,
          borderRadius: BorderRadius.circular(15),
        ),
        alignment: Alignment.centerLeft,
        padding: const EdgeInsets.only(left: 20),
        child: const Icon(Icons.edit, color: Colors.white, size: 28),
      ),

      // ★ 左滑露出的背景 (刪除 - 紅色)
      secondaryBackground: Container(
        margin: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 4.0),
        decoration: BoxDecoration(
          color: Colors.red,
          borderRadius: BorderRadius.circular(15),
        ),
        alignment: Alignment.centerRight,
        padding: const EdgeInsets.only(right: 20),
        child: const Icon(Icons.delete, color: Colors.white, size: 28),
      ),

      // ★ 滑動時的邏輯判斷
      confirmDismiss: (direction) async {
        if (direction == DismissDirection.endToStart) {
          // 左滑：彈出刪除確認視窗
          return await showDialog(
            context: context,
            builder: (BuildContext context) {
              return AlertDialog(
                title: const Text("確認刪除"),
                content: const Text("確定要刪除這筆記帳紀錄嗎？\n(刪除後無法復原)"),
                actions: [
                  TextButton(
                    onPressed: () => Navigator.of(context).pop(false),
                    child: const Text("取消", style: TextStyle(color: Colors.grey)),
                  ),
                  ElevatedButton(
                    onPressed: () => Navigator.of(context).pop(true),
                    style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
                    child: const Text("刪除", style: TextStyle(color: Colors.white)),
                  ),
                ],
              );
            },
          );
        } else if (direction == DismissDirection.startToEnd) {
          // 右滑：編輯
          if (widget.onEditTransaction != null) {
            widget.onEditTransaction!(tx);
          }
          // 回傳 false 代表不把這個元件從畫面上移除 (只是叫出編輯視窗，讓它滑回原位)
          return false;
        }
        return false;
      },

      // ★ 真正確認被滑掉(刪除)後要執行的動作
      onDismissed: (direction) {
        if (direction == DismissDirection.endToStart) {
          if (widget.onDeleteTransaction != null) {
            widget.onDeleteTransaction!(tx.id);
          }
        }
      },

      // 這是原本的交易紀錄 UI (完全沒動排版)
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 4.0),
        child: Container(
          decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(15),
              border: Border.all(color: Colors.grey[200]!)),
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 12.0),
            child: Row(
              children: [
                Container(
                  width: 60,
                  child: Text(
                    tx.category,
                    style: const TextStyle(
                        fontSize: 16, fontWeight: FontWeight.bold),
                  ),
                ),
                Container(
                  width: 70,
                  child: Text(
                    amountString,
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      color: amountColor,
                    ),
                  ),
                ),
                Expanded(
                  child: Container(
                    padding:
                    const EdgeInsets.symmetric(vertical: 8, horizontal: 12),
                    decoration: BoxDecoration(
                      color: Colors.grey[100],
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Text(
                      tx.note.isEmpty ? '-' : tx.note,
                      style: TextStyle(fontSize: 16, color: Colors.grey[800]),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// 搜尋 Delegate (保留你的邏輯)
class TransactionSearchDelegate extends SearchDelegate {
  final List<Transaction> transactions;

  TransactionSearchDelegate(this.transactions);

  @override
  String get searchFieldLabel => '搜尋備註、分類、金額...';

  @override
  List<Widget>? buildActions(BuildContext context) {
    return [
      IconButton(
        icon: const Icon(Icons.clear),
        onPressed: () => query = '',
      ),
    ];
  }

  @override
  Widget? buildLeading(BuildContext context) {
    return IconButton(
      icon: const Icon(Icons.arrow_back),
      onPressed: () => close(context, null),
    );
  }

  @override
  Widget buildResults(BuildContext context) {
    return _buildResultList();
  }

  @override
  Widget buildSuggestions(BuildContext context) {
    return _buildResultList();
  }

  Widget _buildResultList() {
    if (query.isEmpty) {
      return const Center(child: Text('請輸入關鍵字', style: TextStyle(color: Colors.grey)));
    }

    final results = transactions.where((tx) {
      final note = tx.note.toLowerCase();
      final category = tx.category.toLowerCase();
      final amount = tx.amount.toStringAsFixed(0);
      final q = query.toLowerCase();

      return note.contains(q) || category.contains(q) || amount.contains(q);
    }).toList();

    results.sort((a, b) => b.date.compareTo(a.date));

    if (results.isEmpty) {
      return const Center(child: Text('找不到相關紀錄 🐢'));
    }

    return ListView.builder(
      itemCount: results.length,
      padding: const EdgeInsets.all(16),
      itemBuilder: (context, index) {
        final tx = results[index];
        final dateStr = DateFormat('yyyy/MM/dd').format(tx.date);

        return Card(
          margin: const EdgeInsets.only(bottom: 8),
          elevation: 2,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          child: ListTile(
            leading: CircleAvatar(
              backgroundColor: Colors.blue[50],
              child: Icon(tx.categoryIcon, color: Colors.blue),
            ),
            title: Text(tx.category, style: const TextStyle(fontWeight: FontWeight.bold)),
            subtitle: Text("$dateStr\n${tx.note}", maxLines: 2, overflow: TextOverflow.ellipsis),
            isThreeLine: true,
            trailing: Text(
              '${tx.type == TransactionType.expense ? '-' : '+'} \$${tx.amount.toStringAsFixed(0)}',
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
                color: tx.type == TransactionType.expense ? Colors.red : Colors.green,
              ),
            ),
          ),
        );
      },
    );
  }
}

// ===== 城市建築：形狀輔助 =====

enum _BuildingTier { empty, hut, house, apartment, highrise, skyscraper }

class _TriangleClipper extends CustomClipper<Path> {
  @override
  Path getClip(Size size) {
    final path = Path();
    path.moveTo(0, size.height);
    path.lineTo(size.width / 2, 0);
    path.lineTo(size.width, size.height);
    path.close();
    return path;
  }

  @override
  bool shouldReclip(covariant CustomClipper<Path> oldClipper) => false;
}