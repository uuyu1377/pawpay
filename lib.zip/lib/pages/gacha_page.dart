import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

import 'package:user_interface/services/game_api_service.dart';

class GachaPage extends StatefulWidget {
  const GachaPage({super.key});

  @override
  State<GachaPage> createState() => _GachaPageState();
}

class _GachaPageState extends State<GachaPage> with TickerProviderStateMixin {
  late AnimationController _rollController;
  late AnimationController _dropController;
  bool _isRolling = false;
  int _userCoins = 1700;

  List<Offset> _capsulePositions = [];
  final double _globeRadius = 90.0;

  @override
  void initState() {
    super.initState();
    _rollController = AnimationController(vsync: this, duration: const Duration(milliseconds: 100))
      ..addListener(() { if (_isRolling) _updateCapsulePhysics(); });
    _dropController = AnimationController(vsync: this, duration: const Duration(milliseconds: 800));
    _initCapsules();
    _loadCoins();
  }

  Future<void> _loadCoins() async {
    try {
      final money = await GameApiService.instance.fetchPlayerMoney();
      if (!mounted) return;
      setState(() => _userCoins = money);
    } catch (_) {
      // API 尚未啟動時保留本地預設值，避免畫面整個不能看。
    }
  }

  void _initCapsules() {
    final rng = Random();
    _capsulePositions = List.generate(16, (index) {
      double angle = rng.nextDouble() * 2 * pi;
      double r = rng.nextDouble() * (_globeRadius - 20);
      return Offset(r * cos(angle), r * sin(angle));
    });
  }

  void _updateCapsulePhysics() {
    setState(() {
      final rng = Random();
      for (int i = 0; i < _capsulePositions.length; i++) {
        double angle = rng.nextDouble() * 2 * pi;
        double r = 10 + rng.nextDouble() * (_globeRadius - 30);
        _capsulePositions[i] = Offset(r * cos(angle), r * sin(angle));
      }
    });
  }

  @override
  void dispose() {
    _rollController.dispose();
    _dropController.dispose();
    super.dispose();
  }

  // 扭蛋結果由後端寫入 MySQL：扣玩家金錢、抽中則新增 pets。
  void _startGacha() async {
    if (_isRolling || _userCoins < 100) return;
    setState(() => _isRolling = true);

    _rollController.repeat();
    await Future.delayed(const Duration(seconds: 2));
    _rollController.stop();
    await _dropController.forward();
    _dropController.reset();

    Map<String, dynamic>? result;
    try {
      final apiResult = await GameApiService.instance.gachaDraw(cost: 100);
      final money = int.tryParse(apiResult['money']?.toString() ?? '') ?? (_userCoins - 100);
      final pet = apiResult['pet'];
      if (pet is Map) {
        final type = (pet['species_name'] ?? pet['icon_key'] ?? 'dog').toString();
        result = {
          'type': type,
          'name': (pet['name'] ?? pet['species_name'] ?? '新寵物').toString(),
          'color': _getPetColor(type),
        };
      }
      if (mounted) setState(() => _userCoins = money);
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('扭蛋資料庫連線失敗：$e')),
        );
      }
    }

    if (!mounted) return;
    setState(() => _isRolling = false);
    _showResultDialog(result);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFFFF5F5),
      appBar: AppBar(backgroundColor: Colors.transparent, elevation: 0, foregroundColor: Colors.brown),
      body: Center(
        child: Column(
          children: [
            _buildCoinBadge(),
            const Spacer(),
            _buildGachaMachineBody(),
            const SizedBox(height: 50),
            _buildActionBtn(),
            const SizedBox(height: 80),
          ],
        ),
      ),
    );
  }

  Widget _buildCoinBadge() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(30), boxShadow: const [BoxShadow(color: Colors.black12, blurRadius: 10, offset: Offset(0, 4))]),
      child: Row(mainAxisSize: MainAxisSize.min, children: [const Icon(Icons.stars, color: Colors.orangeAccent), const SizedBox(width: 8), Text("$_userCoins 幣", style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.brown))]),
    );
  }

  Widget _buildGachaMachineBody() {
    return SizedBox(
      width: 260, height: 400,
      child: Stack(
        alignment: Alignment.center,
        children: [
          CustomPaint(size: const Size(260, 400), painter: GachaArtPainter()),
          Positioned(left: 0, top: 180, child: _buildSmallHandle(true)),
          Positioned(right: 0, top: 180, child: _buildSmallHandle(false)),
          Positioned(
            top: 60,
            child: Container(
              width: 190, height: 190,
              decoration: const BoxDecoration(shape: BoxShape.circle),
              child: Stack(
                alignment: Alignment.center,
                children: _capsulePositions.asMap().entries.map((e) => _buildBall(e.value, e.key)).toList(),
              ),
            ),
          ),
          AnimatedBuilder(
            animation: _dropController,
            builder: (context, child) {
              if (_dropController.value == 0) return const SizedBox.shrink();
              return Positioned(
                top: 260 + (_dropController.value * 90),
                child: _buildBall(Offset.zero, 0, isFixed: true),
              );
            },
          ),
        ],
      ),
    );
  }

  Widget _buildSmallHandle(bool isLeft) {
    return Transform.rotate(
      angle: _isRolling ? (isLeft ? 1 : -1) * pi * 2 * _rollController.value : 0,
      child: Container(width: 25, height: 45, decoration: BoxDecoration(color: const Color(0xFFB71C1C), borderRadius: BorderRadius.circular(8), border: Border.all(color: Colors.black, width: 3))),
    );
  }

  Widget _buildBall(Offset pos, int index, {bool isFixed = false}) {
    final colors = [Colors.redAccent, Colors.blueAccent, Colors.yellowAccent, Colors.greenAccent, Colors.purpleAccent, Colors.orangeAccent];
    return Positioned(
      left: isFixed ? 78 : (95 + pos.dx - 18),
      top: isFixed ? 0 : (95 + pos.dy - 18),
      child: Container(
        width: 36, height: 36,
        decoration: BoxDecoration(
          shape: BoxShape.circle, border: Border.all(color: Colors.black, width: 2),
          gradient: LinearGradient(colors: [colors[index % 6], Colors.white], begin: Alignment.topCenter, end: Alignment.bottomCenter, stops: const [0.5, 0.51]),
        ),
      ),
    );
  }

  Widget _buildActionBtn() {
    return InkWell(
      onTap: _startGacha,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 50, vertical: 18),
        decoration: BoxDecoration(color: _isRolling ? Colors.grey : const Color(0xFFFF5252), borderRadius: BorderRadius.circular(40), border: Border.all(color: Colors.black, width: 3), boxShadow: const [BoxShadow(color: Colors.black26, offset: Offset(0, 6))]),
        child: Text(_isRolling ? "扭動中..." : "消耗 100 幣 扭一次", style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold)),
      ),
    );
  }

  // --- 修正後的彈窗：動態顯示抽獎結果 ---
  void _showResultDialog(Map<String, dynamic>? res) {
    bool isNone = res == null;
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => Center(
        child: Material(
          color: Colors.transparent,
          child: Container(
            width: 280, padding: const EdgeInsets.all(25),
            decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(30),
                border: Border.all(color: Colors.black, width: 4),
                boxShadow: [BoxShadow(color: Colors.black26, blurRadius: 20, offset: Offset(0, 10))]
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(isNone ? "可惜！" : "🎉 扭蛋結果 🎉", style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: Colors.brown)),
                const SizedBox(height: 25),
                Container(
                  width: 110, height: 110,
                  decoration: BoxDecoration(
                      color: isNone ? Colors.grey[100] : res['color'].withOpacity(0.15),
                      shape: BoxShape.circle,
                      border: Border.all(color: isNone ? Colors.grey : res['color'], width: 4),
                      boxShadow: isNone ? [] : [BoxShadow(color: res['color'].withOpacity(0.4), blurRadius: 15, spreadRadius: 2)]
                  ),
                  child: Icon(
                      isNone ? Icons.sentiment_neutral : _getPetIcon(res['type']),
                      size: 65,
                      color: isNone ? Colors.grey : res['color']
                  ),
                ),
                const SizedBox(height: 20),
                Text(
                  isNone ? "銘謝惠顧" : "恭喜獲得：${res['name']}",
                  style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 10),
                Text(
                  isNone ? "獲得了再接再厲飼料球！" : "新的夥伴已經加入圖鑑囉！",
                  style: const TextStyle(color: Colors.grey, fontSize: 14),
                ),
                const SizedBox(height: 30),
                ElevatedButton(
                  onPressed: () => Navigator.pop(ctx),
                  style: ElevatedButton.styleFrom(
                      backgroundColor: isNone ? Colors.grey[700] : Colors.redAccent,
                      foregroundColor: Colors.white,
                      shape: const StadiumBorder(),
                      padding: const EdgeInsets.symmetric(horizontal: 45, vertical: 15)
                  ),
                  child: const Text("收下", style: TextStyle(fontWeight: FontWeight.bold)),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Color _getPetColor(String type) {
    switch (type) {
      case 'cat': return Colors.blueAccent;
      case 'parrot': return Colors.yellowAccent;
      case 'fox': return Colors.deepOrangeAccent;
      case 'sloth': return Colors.brown[400]!;
      default: return Colors.orangeAccent;
    }
  }

  IconData _getPetIcon(String type) {
    switch (type) {
      case 'dog': return Icons.pets;
      case 'cat': return FontAwesomeIcons.cat;
      case 'parrot': return FontAwesomeIcons.dove;
      case 'fox': return Icons.auto_awesome;
      case 'sloth': return Icons.hourglass_bottom_rounded;
      default: return Icons.pets;
    }
  }
}

class GachaArtPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final bodyPaint = Paint()..color = const Color(0xFFE53935)..style = PaintingStyle.fill;
    final strokePaint = Paint()..color = Colors.black..style = PaintingStyle.stroke..strokeWidth = 4;
    final glassPaint = Paint()..color = Colors.white.withOpacity(0.2)..style = PaintingStyle.fill;

    final capRect = Rect.fromLTWH(size.width / 2 - 60, 25, 120, 40);
    canvas.drawRRect(RRect.fromRectAndRadius(capRect, const Radius.circular(15)), bodyPaint);
    canvas.drawRRect(RRect.fromRectAndRadius(capRect, const Radius.circular(15)), strokePaint);

    canvas.drawCircle(Offset(size.width / 2, 155), 100, glassPaint);
    canvas.drawCircle(Offset(size.width / 2, 155), 100, strokePaint);

    final baseRect = Rect.fromLTWH(size.width / 2 - 85, 240, 170, 130);
    canvas.drawRRect(RRect.fromRectAndRadius(baseRect, const Radius.circular(25)), bodyPaint);
    canvas.drawRRect(RRect.fromRectAndRadius(baseRect, const Radius.circular(25)), strokePaint);

    final signRect = Rect.fromLTWH(size.width / 2 - 40, 310, 80, 40);
    canvas.drawRRect(RRect.fromRectAndRadius(signRect, const Radius.circular(8)), Paint()..color = const Color(0xFFFFFDE7));
    canvas.drawRRect(RRect.fromRectAndRadius(signRect, const Radius.circular(8)), strokePaint);

    canvas.drawCircle(Offset(size.width / 2, 275), 32, Paint()..color = Colors.black45);
    canvas.drawCircle(Offset(size.width / 2, 275), 32, strokePaint);
  }
  @override bool shouldRepaint(covariant CustomPainter old) => false;
}