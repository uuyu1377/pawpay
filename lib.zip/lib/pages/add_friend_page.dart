import 'package:flutter/material.dart';
import 'package:user_interface/services/game_api_service.dart';

class AddFriendPage extends StatefulWidget {
  const AddFriendPage({super.key});

  @override
  State<AddFriendPage> createState() => _AddFriendPageState();
}

class _AddFriendPageState extends State<AddFriendPage> {
  final TextEditingController _controller = TextEditingController();
  bool _isLoading = true;
  List<Map<String, dynamic>> _users = [];
  List<Map<String, dynamic>> _friends = [];

  @override
  void initState() {
    super.initState();
    _loadRecommended();
  }

  Future<void> _loadRecommended() async {
    setState(() => _isLoading = true);
    try {
      final api = GameApiService.instance;
      final friends = await api.fetchFriends();
      final users = await api.fetchRecommendedFriends();
      if (!mounted) return;
      setState(() {
        _friends = friends;
        _users = users;
        _isLoading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() => _isLoading = false);
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('好友資料庫連線失敗：$e')));
    }
  }

  Future<void> _search() async {
    final q = _controller.text.trim();
    if (q.isEmpty) {
      await _loadRecommended();
      return;
    }
    setState(() => _isLoading = true);
    try {
      final users = await GameApiService.instance.searchUsers(query: q);
      if (!mounted) return;
      setState(() {
        _users = users;
        _isLoading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() => _isLoading = false);
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('搜尋失敗：$e')));
    }
  }

  Future<void> _addFriend(Map<String, dynamic> user) async {
    final id = int.tryParse(user['id']?.toString() ?? '') ?? 0;
    if (id <= 0) return;
    try {
      await GameApiService.instance.addFriend(friendId: id);
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('已送出好友邀請給 ${user['nickname'] ?? user['display_name'] ?? id}')));
      await _loadRecommended();
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('新增好友失敗：$e')));
    }
  }

  bool _isFriend(int id) {
    return _friends.any((f) => int.tryParse(f['friend_id']?.toString() ?? '') == id);
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('新增好友'),
        backgroundColor: Colors.white,
        foregroundColor: Colors.black,
        elevation: 0,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _controller,
                    onSubmitted: (_) => _search(),
                    decoration: InputDecoration(
                      hintText: '輸入好友 ID 或名稱',
                      prefixIcon: const Icon(Icons.search),
                      filled: true,
                      fillColor: Colors.grey[100],
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(15), borderSide: BorderSide.none),
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                ElevatedButton(onPressed: _search, child: const Text('搜尋')),
              ],
            ),
            const SizedBox(height: 24),
            Container(
              height: 160,
              width: double.infinity,
              decoration: BoxDecoration(color: Colors.blue[50], borderRadius: BorderRadius.circular(20), border: Border.all(color: Colors.blue.withOpacity(0.3))),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: const [
                  Icon(Icons.qr_code_scanner, size: 56, color: Colors.blue),
                  SizedBox(height: 12),
                  Text('掃描好友 QR Code', style: TextStyle(color: Colors.blue)),
                  SizedBox(height: 4),
                  Text('目前先保留入口，之後可接 QR 掃描。', style: TextStyle(color: Colors.blueGrey, fontSize: 12)),
                ],
              ),
            ),
            const SizedBox(height: 24),
            const Align(alignment: Alignment.centerLeft, child: Text('推薦 / 搜尋結果', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold))),
            const SizedBox(height: 12),
            Expanded(
              child: _isLoading
                  ? const Center(child: CircularProgressIndicator())
                  : _users.isEmpty
                      ? const Center(child: Text('目前沒有符合的使用者'))
                      : ListView.builder(
                          itemCount: _users.length,
                          itemBuilder: (context, index) {
                            final user = _users[index];
                            final id = int.tryParse(user['id']?.toString() ?? '') ?? 0;
                            final added = _isFriend(id);
                            final name = (user['nickname'] ?? user['display_name'] ?? '玩家 $id').toString();
                            return ListTile(
                              leading: CircleAvatar(backgroundColor: Colors.primaries[index % Colors.primaries.length], child: Text(name.isNotEmpty ? name.substring(0, 1) : '?')),
                              title: Text(name),
                              subtitle: Text('ID: $id • ${user['email'] ?? 'local'}'),
                              trailing: ElevatedButton(
                                onPressed: added ? null : () => _addFriend(user),
                                style: ElevatedButton.styleFrom(shape: const StadiumBorder(), elevation: 0),
                                child: Text(added ? '已加入' : '加入'),
                              ),
                            );
                          },
                        ),
            ),
          ],
        ),
      ),
    );
  }
}
