import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:shared_preferences/shared_preferences.dart'; // ★ 新增：用來儲存專屬使用者 ID
import 'dart:math'; // ★★★ 新增這行：用來產生隨機數字 ★★★

// 1. ★ 修正路徑 ★
// 假設 main_app_shell.dart 在 lib/ 底下
// 而 login_page.dart 在 lib/pages/ 底下
// 我們用 ../ 回到上一層 (lib)，然後找到 main_app_shell.dart
import '../main_app_shell.dart';
import 'onboarding_page.dart';

class LoginPage extends StatelessWidget {
  const LoginPage({super.key});

  // 輔助函式：用來處理所有登入按鈕的跳轉
  // ★ 修改：改成 async 異步執行，在跳轉前先建立並儲存使用者的專屬 ID
  void _navigateToHome(BuildContext context) async {
    final prefs = await SharedPreferences.getInstance();
    String? currentUserId = prefs.getString('user_id');

    // 如果這支手機還沒有 ID，就幫他自動生成一個專屬的 (模擬真實註冊/登入)
    if (currentUserId == null || currentUserId.isEmpty) {
      // ★ 修正：MySQL 的 id 只能吃整數，所以我們產生一組 9 位數的隨機純數字
      String newUserId = (Random().nextInt(900000000) + 100000000).toString();
      await prefs.setString('user_id', newUserId);
      debugPrint("✅ 建立純數字新帳號 ID: $newUserId");
    } else {
      debugPrint("✅ 歡迎回來，登入現有帳號 ID: $currentUserId");
    }

    // ★ 修改：改成跳轉到 OnboardingPage
    if (context.mounted) {
      Navigator.of(context).pushReplacement(
        MaterialPageRoute(builder: (context) => const OnboardingPage()),
      );
    }
  }

  // ... (檔案的其餘部分保持不變) ...
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 24.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const SizedBox(height: 40),
              const Text(
                '建立帳號',
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                  color: Colors.black,
                ),
              ),
              const SizedBox(height: 8),
              const Text(
                '輸入電子郵件以註冊',
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 16,
                  color: Colors.grey,
                ),
              ),
              const SizedBox(height: 32),
              TextField(
                decoration: InputDecoration(
                  hintText: 'email@domain.com',
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                    borderSide: BorderSide.none,
                  ),
                  filled: true,
                  fillColor: Colors.grey[200],
                  contentPadding: const EdgeInsets.symmetric(
                      vertical: 16, horizontal: 20),
                ),
                keyboardType: TextInputType.emailAddress,
              ),
              const SizedBox(height: 20),

              // Continue 按鈕
              ElevatedButton(
                onPressed: () => _navigateToHome(context),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.black,
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(vertical: 12),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                  elevation: 0,
                ),
                child: const Text(
                  'Continue',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                ),
              ),
              const SizedBox(height: 30),
              Row(
                children: [
                  const Expanded(child: Divider(color: Colors.grey)),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16.0),
                    child: Text(
                      'or',
                      style: TextStyle(color: Colors.grey[600], fontSize: 16),
                    ),
                  ),
                  const Expanded(child: Divider(color: Colors.grey)),
                ],
              ),
              const SizedBox(height: 30),

              // Google, Apple, LINE, Phone 按鈕
              _buildSocialButton(
                context,
                text: '使用 Google 登入',
                icon: FontAwesomeIcons.google,
                color: Colors.white,
                textColor: Colors.black,
                onPressed: () => _navigateToHome(context),
              ),
              const SizedBox(height: 8),
              _buildSocialButton(
                context,
                text: '使用 Apple 登入',
                icon: FontAwesomeIcons.apple,
                color: Colors.black,
                textColor: Colors.white,
                onPressed: () => _navigateToHome(context),
              ),
              const SizedBox(height: 12),
              _buildSocialButton(
                context,
                text: '使用 LINE 登入',
                icon: FontAwesomeIcons.line,
                color: const Color(0xFF00C300),
                textColor: Colors.white,
                onPressed: () => _navigateToHome(context),
              ),
              const SizedBox(height: 12),
              _buildSocialButton(
                context,
                text: '使用手機號碼登入',
                icon: FontAwesomeIcons.phoneFlip,
                color: Colors.grey[200]!,
                textColor: Colors.black,
                onPressed: () => _navigateToHome(context),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildSocialButton(
      BuildContext context, {
        required String text,
        required IconData icon,
        required Color color,
        required Color textColor,
        required VoidCallback onPressed,
      }) {
    return ElevatedButton.icon(
      onPressed: onPressed,
      style: ElevatedButton.styleFrom(
        backgroundColor: color,
        foregroundColor: textColor,
        padding: const EdgeInsets.symmetric(vertical: 12),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(10),
          side: color == Colors.white
              ? const BorderSide(color: Colors.grey)
              : BorderSide.none,
        ),
        elevation: 0,
      ),
      icon: Icon(icon, size: 20),
      label: Text(
        text,
        style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
      ),
    );
  }
}