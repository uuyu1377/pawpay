import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;
import 'package:lottie/lottie.dart'; // Lottie 動畫套件

import 'package:user_interface/models/transaction_model.dart';
import 'package:user_interface/widgets/new_transaction_sheet.dart';
import 'package:user_interface/services/database_helper.dart';

import 'pages/home_page.dart';
import 'pages/playground_page.dart';
import 'pages/setting_page.dart';
import 'pages/voice_page.dart';
import 'config/backend_config.dart';

import 'package:user_interface/services/local_ai_service.dart'; // 請確認路徑是否正確

enum ScanMode { auto, traditional }

class MainAppShell extends StatefulWidget {
  const MainAppShell({super.key});

  @override
  State<MainAppShell> createState() => _MainAppShellState();
}

class _MainAppShellState extends State<MainAppShell> {
  int _selectedIndex = 1;
  List<Transaction> _transactions = [];
  static const _kPrefKey = 'scan_mode';
  ScanMode _scanMode = ScanMode.auto;

  bool _isAnalyzing = false;

  // ★★★ 新增：記錄今天是否為第一筆記帳 ★★★
  bool _isFirstTransactionToday = false;

  String _userIdentity = "u23";
  String _userNickname = "使用者";
  bool _useAiSuggestion = true;
  bool _dailyReminderEnabled = true;
  String _dailyReminderTime = "21:00";
  bool _monthlyBudgetReminderEnabled = true;
  int _monthlyBudgetAmount = 0;
  int _budgetThreshold = 90;

  // ===== AI 暫存（用來把「掃描/語音原文、商家、發票、tags、AI摘要」寫進 V2 記帳表）=====
  String? _pendingEntryMethod; // scan | voice | manual(預留)
  String? _pendingRawInput; // QR/OCR/語音原文
  String? _pendingAiJson; // AI 回傳的 raw JSON（字串）
  String? _pendingMerchant;
  String? _pendingItemsSummary;
  String? _pendingInvoiceNumber;
  double? _pendingAiConfidence;
  String? _pendingSuggestedSubCategory;
  String? _pendingAiModel;
  DateTime? _pendingOccurredAt;
  List<String> _pendingTags = [];

  final GlobalKey<HomePageState> _homeKey = GlobalKey<HomePageState>();

  // Lottie 動畫清單
  final List<String> _loadingAnimations = [
    'assets/animations/Dog.json',
    'assets/animations/Cat.json',
    'assets/animations/Fox.json',
    'assets/animations/Parrot.json',
    'assets/animations/Sloth.json',
  ];

  // 發票圖片路徑
  final String _invoiceIconPath = 'assets/images/invoice_icon.png';

  // ★★★ 修正：完整分類表 (依照您的詳細清單更新，包含完整收入與支出) ★★★
  final Map<String, Map<String, dynamic>> _categoryData = {
    // ==========================================
    // 支出 - 1. 通用分類 (Target: All)
    // ==========================================
    "飲食": {
      "group": "all",
      "subs": ["早餐", "午餐", "晚餐", "飲料/咖啡", "宵夜", "零食", "外送", "聚餐"]
    },
    "交通": {
      "group": "all",
      "subs": ["公車", "捷運", "火車/高鐵", "計程車/Uber", "加油", "停車費", "車輛維修"]
    },
    "生活用品": {
      "group": "all",
      "subs": ["超市採買", "衛生紙/日用品", "五金百貨", "洗衣/清潔"]
    },
    "社交": {
      "group": "all",
      "subs": ["請客", "社交應酬", "派對活動"]
    },
    "娛樂": {
      "group": "all",
      "subs": ["電影", "KTV", "展覽/表演", "書籍/雜誌", "遊戲", "串流影音"]
    },
    "通訊網路": {
      "group": "all",
      "subs": ["手機費", "網路費"]
    },
    "服飾美容": {
      "group": "all",
      "subs": ["衣服/鞋子", "配件", "化妝品/保養品", "剪髮/美容", "美甲/按摩"]
    },
    "醫療健康": {
      "group": "all",
      "subs": ["看診掛號", "藥品", "保健食品", "運動/健身房"]
    },
    "住房": {
      "group": "all",
      "subs": ["房租", "水電費", "瓦斯費", "管理費"]
    },
    "其他支出": {
      "group": "all",
      "subs": ["雜費", "手續費", "捐款", "其他"]
    },

    // ==========================================
    // 支出 - 2. 學生專屬 (Target: Student)
    // ==========================================
    "學費與教材": {
      "group": "student",
      "subs": ["學雜費", "參考書/課本", "補習班", "影印費", "文具"]
    },
    "線上訂閱": {
      "group": "student",
      "subs": ["Netflix", "Spotify", "YouTube Premium", "iCloud/Google Drive", "Disney+"]
    },
    "小確幸": {
      "group": "student",
      "subs": ["扭蛋", "盲盒", "公仔", "遊戲課金", "周邊商品"]
    },
    "禮物與送禮": {
      "group": "student",
      "subs": ["生日禮物", "節日送禮", "伴手禮"]
    },
    "不見了": {
      "group": "student",
      "subs": ["現金遺失", "物品遺失重買", "錢包弄丟"]
    },

    // ==========================================
    // 支出 - 3. 上班族專屬 (Target: Worker)
    // ==========================================
    "投資理財": {
      "group": "worker",
      "subs": ["股票買入", "基金申購", "定期定額扣款"]
    },
    "家具家電": {
      "group": "worker",
      "subs": ["大型家具", "小家電", "廚房用具", "居家佈置"]
    },

    // ==========================================
    // 支出 - 4. 家庭專屬 (Target: Family)
    // ==========================================
    "房貸與修繕": {
      "group": "family",
      "subs": ["房屋貸款", "房屋修繕", "裝潢費用", "房屋稅/地價稅"]
    },
    "小孩教育": {
      "group": "family",
      "subs": ["學費", "安親班", "才藝課", "尿布奶粉", "玩具/童書"]
    },
    "保險費用": {
      "group": "family",
      "subs": ["壽險", "醫療險", "車險", "儲蓄險"]
    },
    "長輩支出": {
      "group": "family",
      "subs": ["孝親費", "長輩醫療", "長輩看護"]
    },
    "家庭旅遊": {
      "group": "family",
      "subs": ["機票住宿", "旅行團費", "全家出遊餐飲"]
    },

    // ==========================================
    // 收入 - 5. 通用分類 (Target: All)
    // ==========================================
    "薪水": {
      "group": "all",
      "subs": ["正職薪資", "年終獎金", "加班費"]
    },
    "投資收益": {
      "group": "all",
      "subs": ["股票股利", "基金配息", "價差獲利"]
    },
    "禮金": {
      "group": "all",
      "subs": ["紅包收入", "三節禮金"]
    },
    "其他收入": {
      "group": "all",
      "subs": ["二手拍賣", "發票中獎", "退款"]
    },

    // ==========================================
    // 收入 - 6. 學生專屬 (Target: Student)
    // ==========================================
    "零用錢": {
      "group": "student",
      "subs": ["父母給的", "長輩給的"]
    },
    "打工收入": {
      "group": "student",
      "subs": ["家教費", "工讀薪資", "校內工讀"]
    },
    "獎學金": {
      "group": "student",
      "subs": ["校內獎學金", "系上獎學金", "校外補助"]
    },

    // ==========================================
    // 收入 - 7. 上班族專屬 (Target: Worker)
    // ==========================================
    "投資獲利": {
      "group": "worker",
      "subs": ["短期操作獲利", "虛擬貨幣獲利"]
    },

    // ==========================================
    // 收入 - 8. 家庭專屬 (Target: Family)
    // ==========================================
    "被動收入": {
      "group": "family",
      "subs": ["房租收入", "銀行利息", "股息收入"]
    },
    "退稅/補助": {
      "group": "family",
      "subs": ["所得稅退稅", "育兒津貼", "租屋補助", "政府補助"]
    }
  };

  @override
  void initState() {
    super.initState();
    _loadScanMode();
    _loadUserProfile();
    _loadData().then((_) {
      // 確保資料載入完畢後，再檢查是否要彈出總結
      WidgetsBinding.instance.addPostFrameCallback((_) {
        _checkAndShowDailySummary();
        _checkInAppDailyReminder();
      });
    });
  }

  // ★★★ 新增：自動取得並儲存 JWT Token 的函式 ★★★
  Future<String?> _getAuthToken() async {
    final prefs = await SharedPreferences.getInstance();
    String? token = prefs.getString('jwt_token');

    // 如果手機裡沒有 Token，就去跟後端拿一張新的
    if (token == null || token.isEmpty) {
      try {
        final url = Uri.parse('${BackendConfig.baseUrl}/api/login');
        // ★★★ 修改：從手機裡抓取我們在登入頁建立的真實 user_id ★★★
        String currentUserId = prefs.getString('user_id') ?? "unknown_user";

        final response = await http.post(
          url,
          headers: {"Content-Type": "application/json"},
          body: jsonEncode({"user_id": currentUserId}),
        ).timeout(const Duration(seconds: 10));

        if (response.statusCode == 200) {
          final resJson = jsonDecode(response.body);
          token = resJson['token'];
          await prefs.setString('jwt_token', token!); // 存進手機裡
          debugPrint("✅ 成功獲取並儲存 JWT Token");
        } else {
          debugPrint("❌ 獲取 Token 失敗：狀態碼 ${response.statusCode}");
        }
      } catch (e) {
        debugPrint("❌ 獲取 Token 發生錯誤: $e");
      }
    }
    return token;
  }

  // ★★★ 新增：從本地記憶體撈出當日明細字串 ★★★
  String _getTransactionsTextForDate(DateTime date) {
    String dateString = "${date.year}-${date.month.toString().padLeft(2, '0')}-${date.day.toString().padLeft(2, '0')}";
    List<String> items = [];

    for (var tx in _transactions) {
      String txDateStr = "${tx.date.year}-${tx.date.month.toString().padLeft(2, '0')}-${tx.date.day.toString().padLeft(2, '0')}";
      if (txDateStr == dateString && tx.type == TransactionType.expense) {
        String notePart = tx.note.isNotEmpty ? "(${tx.note})" : "";
        items.add("${tx.category} \$${tx.amount.toInt()} $notePart");
      }
    }

    if (items.isEmpty) return "無紀錄";
    return items.join("\n");
  }

  // ★★★ 修改：每日總結檢查核心邏輯 (永遠結算昨天) ★★★
  Future<void> _checkAndShowDailySummary() async {
    final prefs = await SharedPreferences.getInstance();
    final now = DateTime.now();

    // 1. 新手保護期判斷
    final todayStr = "${now.year}-${now.month.toString().padLeft(2, '0')}-${now.day.toString().padLeft(2, '0')}";
    String? firstOpenDate = prefs.getString('first_open_date');
    if (firstOpenDate == null) {
      // 第一次打開 App，記錄今天，且不顯示任何總結
      await prefs.setString('first_open_date', todayStr);
      return;
    }

    // 2. 決定「結算日」是哪一天 (永遠結算完整的「昨天」)
    DateTime targetDate = now.subtract(const Duration(days: 1));
    String displayDayText = "昨天";

    final targetDateStr = "${targetDate.year}-${targetDate.month.toString().padLeft(2, '0')}-${targetDate.day.toString().padLeft(2, '0')}";

    // 新手保護期二次防呆：如果要結算的日子比註冊日還早，就不結算
    if (targetDateStr.compareTo(firstOpenDate) < 0) {
      return;
    }

    // 3. 檢查是否已經看過這個日期的總結了
    String? lastSummaryDate = prefs.getString('last_summary_date');
    if (lastSummaryDate == targetDateStr) {
      return; // 看過了，不打擾
    }

    // 4. 去資料庫撈這天的總花費與筆數
    final summary = await DatabaseHelper.instance.getSummaryForDate(targetDate);
    final count = summary['count'] as int;
    final total = summary['total'] as double;

    // 5. 準備彈窗的基本元素
    String dialogTitle = "$displayDayText理財任務結算";

    // 0 筆：直接顯示生氣狗，不呼叫 AI
    if (count == 0) {
      if (mounted) {
        showDialog(
            context: context,
            barrierDismissible: false,
            builder: (ctx) {
              return _buildSummaryDialog(
                ctx: ctx,
                title: dialogTitle,
                lottieAsset: 'assets/animations/Angry Dog.json',
                total: total,
                count: count,
                dialogText: "氣噗噗！$displayDayText都沒看到主人來記帳，狗狗餓肚子等很久了...明天不准忘記！",
                isLoading: false,
              );
            }
        );
      }
      await prefs.setString('last_summary_date', targetDateStr);
      return;
    }

    // > 0 筆：呼叫 AI，使用外部變數管理狀態，避免 StatefulBuilder 無限重置
    String currentDialogText = "汪！狗狗正在拿著計算機，幫你結算$displayDayText的每一筆帳單，稍等我一下喔...";
    bool isAiLoading = true;
    bool hasCalledApi = false; // ★★★ 新增：API 防護鎖，確保只發送一次 ★★★
    String lottieAsset = (count <= 2) ? 'assets/animations/Angry Dog.json' : 'assets/animations/Happy Dog.json';

    if (mounted) {
      showDialog(
          context: context,
          barrierDismissible: false,
          builder: (ctx) {
            return StatefulBuilder(
                builder: (context, setStateDialog) {
                  // ★★★ 修正：如果正在載入，且「還沒呼叫過 API」，才啟動 API 呼叫 ★★★
                  if (isAiLoading && !hasCalledApi) {
                    hasCalledApi = true; // 立刻上鎖，防止畫圖工人瘋狂重複呼叫
                    _fetchAiSummary(targetDate, total, displayDayText).then((aiResult) {
                      if (mounted) {
                        setStateDialog(() {
                          currentDialogText = aiResult;
                          isAiLoading = false;
                        });
                      }
                    });
                  }

                  return _buildSummaryDialog(
                    ctx: ctx,
                    title: dialogTitle,
                    lottieAsset: lottieAsset,
                    total: total,
                    count: count,
                    dialogText: currentDialogText,
                    isLoading: isAiLoading,
                  );
                }
            );
          }
      );
    }

    // 7. 記錄已經看過
    await prefs.setString('last_summary_date', targetDateStr);
  }

  // ★★★ 新增：呼叫後端 AI 進行總結的獨立函式 ★★★
  Future<String> _fetchAiSummary(DateTime date, double totalAmount, String dateText) async {
    try {
      final token = await _getAuthToken(); // ★ 1. 拿出 Token
      final transactionsText = _getTransactionsTextForDate(date);
      final url = Uri.parse('${BackendConfig.baseUrl}/summary');

      final response = await http.post(
        url,
        headers: {
          "Content-Type": "application/json",
          if (token != null) "Authorization": "Bearer $token", // ★ 2. 夾在 Header 送出
        },
        body: jsonEncode({
          "transactions_text": transactionsText,
          "total_amount": totalAmount,
          "user_input": "我是$_userNickname",
          "date_text": dateText
        }),
      ).timeout(const Duration(seconds: 15));

      if (response.statusCode == 200) {
        final resJson = jsonDecode(response.body);
        return resJson['comment'] ?? "太神啦！$dateText記了好多筆，狗狗幫你把總帳單算清楚囉！";
      } else {
        return "汪... 狗狗的計算機好像壞掉了，總之$dateText辛苦啦！";
      }
    } catch (e) {
      print("AI Summary Error: $e");
      return "汪... 狗狗算數算到睡著了，總之$dateText辛苦啦！";
    }
  }

  // ★★★ 新增：獨立抽出 Dialog UI，方便 StatefulBuilder 更新 ★★★
  Widget _buildSummaryDialog({
    required BuildContext ctx,
    required String title,
    required String lottieAsset,
    required double total,
    required int count,
    required String dialogText,
    required bool isLoading,
  }) {
    return Dialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      child: Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(20),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              title,
              style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.amber),
            ),
            const SizedBox(height: 16),

            // Lottie 動畫區
            SizedBox(
              height: 150,
              child: Lottie.asset(lottieAsset, fit: BoxFit.contain),
            ),
            const SizedBox(height: 16),

            // 總金額顯示
            Text(
              "總花費 \$${total.toStringAsFixed(0)}",
              style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w900),
            ),
            Text(
              "記帳筆數：$count 筆",
              style: const TextStyle(fontSize: 14, color: Colors.grey),
            ),
            const SizedBox(height: 20),

            // 狗狗台詞區 (對話氣泡感)
            Container(
              padding: const EdgeInsets.all(12),
              width: double.infinity,
              decoration: BoxDecoration(
                color: Colors.blue.shade50,
                borderRadius: BorderRadius.circular(12),
              ),
              child: isLoading
                  ? Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const SizedBox(
                      width: 16,
                      height: 16,
                      child: CircularProgressIndicator(strokeWidth: 2)
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Text(
                      dialogText,
                      style: const TextStyle(fontSize: 14, height: 1.5),
                      textAlign: TextAlign.left,
                    ),
                  ),
                ],
              )
                  : Text(
                dialogText,
                style: const TextStyle(fontSize: 14, height: 1.5),
                textAlign: TextAlign.center,
              ),
            ),
            const SizedBox(height: 20),

            // 確認按鈕 (載入中時反灰不能按)
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: isLoading ? Colors.grey : Colors.black,
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                  padding: const EdgeInsets.symmetric(vertical: 12),
                ),
                onPressed: isLoading ? null : () {
                  Navigator.of(ctx).pop();
                },
                child: const Text("摸摸牠的頭，明天繼續努力"),
              ),
            )
          ],
        ),
      ),
    );
  }

  String _todayKey(DateTime date) {
    return "${date.year}-${date.month.toString().padLeft(2, '0')}-${date.day.toString().padLeft(2, '0')}";
  }

  String _monthKey(DateTime date) {
    return "${date.year}-${date.month.toString().padLeft(2, '0')}";
  }

  TimeOfDay _parseReminderTime(String text) {
    final parts = text.split(':');
    return TimeOfDay(
      hour: int.tryParse(parts.first) ?? 21,
      minute: parts.length > 1 ? int.tryParse(parts[1]) ?? 0 : 0,
    );
  }

  bool _isAfterTime(DateTime now, TimeOfDay time) {
    if (now.hour > time.hour) return true;
    if (now.hour == time.hour && now.minute >= time.minute) return true;
    return false;
  }

  String _money(num value) {
    final text = value.round().toString();
    return text.replaceAllMapped(
      RegExp(r'\B(?=(\d{3})+(?!\d))'),
      (match) => ',',
    );
  }

  Future<void> _checkInAppDailyReminder() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final enabled = prefs.getBool('setting_daily_reminder') ?? _dailyReminderEnabled;
      if (!enabled) return;

      final now = DateTime.now();
      final reminderTime = _parseReminderTime(prefs.getString('setting_daily_reminder_time') ?? _dailyReminderTime);
      if (!_isAfterTime(now, reminderTime)) return;

      final today = _todayKey(now);
      if (prefs.getString('last_daily_reminder_date') == today) return;

      final hasRecord = await DatabaseHelper.instance.hasTransactionsOnDate(now);
      if (hasRecord) return;

      await prefs.setString('last_daily_reminder_date', today);
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('今天還沒有記帳紀錄，要不要補登一下？'),
          duration: Duration(seconds: 4),
        ),
      );
    } catch (e) {
      debugPrint('每日提醒檢查失敗：$e');
    }
  }

  Future<void> _checkMonthlyBudgetAfterSave({required bool isIncome}) async {
    if (isIncome) return;
    try {
      final prefs = await SharedPreferences.getInstance();
      final enabled = prefs.getBool('setting_monthly_budget_reminder') ?? _monthlyBudgetReminderEnabled;
      final budget = prefs.getInt('setting_monthly_budget_amount') ?? _monthlyBudgetAmount;
      final threshold = prefs.getInt('setting_budget_threshold') ?? _budgetThreshold;
      if (!enabled || budget <= 0) return;

      final now = DateTime.now();
      final spent = _transactions
          .where((tx) =>
              tx.type == TransactionType.expense &&
              tx.date.year == now.year &&
              tx.date.month == now.month)
          .fold<double>(0, (sum, tx) => sum + tx.amount.abs());

      final percent = spent / budget * 100;
      final level = percent >= 100 ? 100 : (percent >= threshold ? threshold : 0);
      if (level == 0) return;

      final key = 'last_budget_alert_level_${_monthKey(now)}';
      final lastLevel = prefs.getInt(key) ?? 0;
      if (lastLevel >= level) return;
      await prefs.setInt(key, level);

      if (!mounted) return;
      final title = level >= 100 ? '月底預算已超過' : '月底預算提醒';
      final msg = level >= 100
          ? '本月已花 ${_money(spent)} 元，已超過預算 ${_money(budget)} 元。'
          : '本月已花 ${_money(spent)} 元，已達預算 ${percent.round()}%。';
      showDialog(
        context: context,
        builder: (ctx) => AlertDialog(
          title: Text(title),
          content: Text('$msg\n\n可以到設定頁調整月底預算或提醒門檻。'),
          actions: [
            TextButton(onPressed: () => Navigator.of(ctx).pop(), child: const Text('知道了')),
          ],
        ),
      );
    } catch (e) {
      debugPrint('月底預算提醒檢查失敗：$e');
    }
  }

  Future<void> _loadData() async {
    final data = await DatabaseHelper.instance.getAllTransactions();

    // ★★★ 新增：判斷今天是否為第一筆 ★★★
    final hasTodayRecord = await DatabaseHelper.instance.hasTransactionsOnDate(DateTime.now());

    if (mounted) {
      setState(() {
        _transactions = data;
        _isFirstTransactionToday = !hasTodayRecord; // 如果沒有紀錄，這就是第一筆
      });
    }
  }

  int _defaultBudgetForIdentity(String code) {
    switch (code) {
      case 'a23_35':
        return 25000;
      case 'a35p':
        return 50000;
      case 'u23':
      default:
        return 8000;
    }
  }

  Future<void> _loadRuntimeSettings() async {
    final prefs = await SharedPreferences.getInstance();
    final identity = prefs.getString('user_identity') ?? "u23";
    if (!mounted) return;
    setState(() {
      _userIdentity = identity;
      _userNickname = prefs.getString('user_nickname') ?? "使用者";
      _useAiSuggestion = prefs.getBool('setting_ai_suggestion') ?? true;
      _dailyReminderEnabled = prefs.getBool('setting_daily_reminder') ?? true;
      _dailyReminderTime = prefs.getString('setting_daily_reminder_time') ?? "21:00";
      _monthlyBudgetReminderEnabled = prefs.getBool('setting_monthly_budget_reminder') ?? true;
      _monthlyBudgetAmount = prefs.getInt('setting_monthly_budget_amount') ?? _defaultBudgetForIdentity(identity);
      _budgetThreshold = prefs.getInt('setting_budget_threshold') ?? 90;
    });
  }

  Future<void> _loadUserProfile() async {
    final prefs = await SharedPreferences.getInstance();
    final identity = prefs.getString('user_identity') ?? "u23";
    setState(() {
      _userIdentity = identity;
      _userNickname = prefs.getString('user_nickname') ?? "使用者";
      _useAiSuggestion = prefs.getBool('setting_ai_suggestion') ?? true;
      _dailyReminderEnabled = prefs.getBool('setting_daily_reminder') ?? true;
      _dailyReminderTime = prefs.getString('setting_daily_reminder_time') ?? "21:00";
      _monthlyBudgetReminderEnabled = prefs.getBool('setting_monthly_budget_reminder') ?? true;
      _monthlyBudgetAmount = prefs.getInt('setting_monthly_budget_amount') ?? _defaultBudgetForIdentity(identity);
      _budgetThreshold = prefs.getInt('setting_budget_threshold') ?? 90;
    });
    await DatabaseHelper.instance.initializeUserIdentity(_userIdentity);

    // ★★★ 新增：從快取抓取註冊方式，並同步寫入深層 SQLite 資料庫 ★★★
    String authProvider = prefs.getString('auth_provider') ?? "local";
    await DatabaseHelper.instance.updateUserInfo(_userNickname, authProvider);
  }

  Future<void> _loadScanMode() async {
    final sp = await SharedPreferences.getInstance();
    final m = sp.getString(_kPrefKey);
    setState(() {
      _scanMode = (m == 'traditional') ? ScanMode.traditional : ScanMode.auto;
    });
  }

  Future<void> _toggleScanMode() async {
    final next = (_scanMode == ScanMode.auto) ? ScanMode.traditional : ScanMode.auto;
    final sp = await SharedPreferences.getInstance();
    await sp.setString(_kPrefKey, next == ScanMode.traditional ? 'traditional' : 'auto');
    setState(() => _scanMode = next);
  }

  Future<void> _goScan() async {
    final routeName = _scanMode == ScanMode.auto ? '/scan' : '/scan/traditional';
    final result = await Navigator.of(context).pushNamed(routeName);
    if (result != null && result is String && result.isNotEmpty) {
      await _handleScanResult(result);
    }
  }

  Future<void> _onVoiceBtnPressed() async {
    final result = await Navigator.of(context).push(
      MaterialPageRoute(builder: (context) => const VoicePage()),
    );
    if (result != null && result is Map && result['type'] == 'voice_input') {
      String text = result['text'];
      await _handleVoiceAnalysis(text);
    }
  }

  Future<void> _handleVoiceAnalysis(String voiceText) async {
    setState(() => _isAnalyzing = true);
    _pendingEntryMethod = 'voice';
    _pendingRawInput = voiceText;

    try {
      final token = await _getAuthToken(); // ★ 1. 拿出 Token
      final url = Uri.parse('${BackendConfig.baseUrl}/classify');
      final now = DateTime.now();
      String timeStr = "${now.hour.toString().padLeft(2, '0')}:${now.minute.toString().padLeft(2, '0')}";

      final response = await http.post(
        url,
        headers: {
          "Content-Type": "application/json",
          if (token != null) "Authorization": "Bearer $token", // ★ 2. 夾在 Header 送出
        },
        body: jsonEncode({
          "scanned_content": "",
          "user_input": voiceText,
          "identity": _userIdentity,
          "current_time": timeStr
        }),
      ).timeout(const Duration(seconds: 20));

      if (response.statusCode == 200) {
        final resJson = jsonDecode(response.body);
        _processAiResponse(resJson);
      } else {
        if (mounted) _showErrorSnackBar('AI 分析失敗: ${response.statusCode}');
      }
    } catch (e) {
      if (mounted) _showErrorSnackBar('連線錯誤: $e');
    } finally {
      if (mounted) setState(() => _isAnalyzing = false);
    }
  }

  Future<void> _handleScanResult(String scannedText) async {
    setState(() => _isAnalyzing = true);
    _pendingEntryMethod = 'scan';
    _pendingRawInput = scannedText;

    try {
      final token = await _getAuthToken(); // ★ 1. 拿出 Token
      final url = Uri.parse('${BackendConfig.baseUrl}/classify');
      final now = DateTime.now();
      String timeStr = "${now.hour.toString().padLeft(2, '0')}:${now.minute.toString().padLeft(2, '0')}";

      final response = await http.post(
        url,
        headers: {
          "Content-Type": "application/json",
          if (token != null) "Authorization": "Bearer $token", // ★ 2. 夾在 Header 送出
        },
        body: jsonEncode({
          "scanned_content": scannedText,
          "user_input": "我是$_userNickname",
          "identity": _userIdentity,
          "current_time": timeStr
        }),
      ).timeout(const Duration(seconds: 20));

      if (response.statusCode == 200) {
        final resJson = jsonDecode(response.body);
        _processAiResponse(resJson);
      } else {
        if (mounted) _showErrorSnackBar('AI 分析失敗: ${response.statusCode}');
      }
    } catch (e) {
      if (mounted) _showErrorSnackBar('連線錯誤: $e');
    } finally {
      if (mounted) setState(() => _isAnalyzing = false);
    }
  }

  void _processAiResponse(dynamic resJson) {
    final data = resJson['data'];
    double amount = data['amount'] != null ? (data['amount'] as num).toDouble() : 0.0;
    String mainCat = data['matched_main_category'] ?? "";
    String subCat = data['matched_sub_category'] ?? "";

    // ★★★ 終極完整版：AI 翻譯蒟蒻 (字詞校正防呆) ★★★
    // 解決 AI 偷懶省略字，導致預設分類被誤認為自創 (is_custom=1) 的問題
    final s = subCat.trim().toLowerCase(); // 轉小寫並去空白，防呆更徹底

    // 1. 飲食 / 交通
    if (s == '飲料' || s == '咖啡' || s == '手搖飲') subCat = '飲料/咖啡';
    if (s == '火車' || s == '高鐵' || s == '台鐵') subCat = '火車/高鐵';
    if (s == '計程車' || s == 'uber' || s == '叫車') subCat = '計程車/Uber';

    // 2. 生活用品
    if (s == '衛生紙' || s == '日用品') subCat = '衛生紙/日用品';
    if (s == '洗衣' || s == '清潔' || s == '洗衣服') subCat = '洗衣/清潔';
    if (s == '五金' || s == '百貨' || s == '五金行') subCat = '五金百貨';

    // 3. 娛樂 / 社交
    if (s == '展覽' || s == '表演' || s == '看展') subCat = '展覽/表演';
    if (s == '書籍' || s == '雜誌' || s == '買書') subCat = '書籍/雜誌';
    if (s == '串流' || s == '影音') subCat = '串流影音';

    // 4. 服飾美容 / 醫療
    if (s == '衣服' || s == '鞋子' || s == '買衣服' || s == '買鞋') subCat = '衣服/鞋子';
    if (s == '化妝品' || s == '保養品' || s == '化妝' || s == '保養') subCat = '化妝品/保養品';
    if (s == '剪髮' || s == '美容' || s == '理髮' || s == '做臉') subCat = '剪髮/美容';
    if (s == '美甲' || s == '按摩' || s == '做指甲') subCat = '美甲/按摩';
    if (s == '看診' || s == '掛號' || s == '門診' || s == '看病') subCat = '看診掛號';

    // 5. 學生專屬
    if (s == '參考書' || s == '課本') subCat = '參考書/課本';
    if (s == 'icloud' || s == 'google drive' || s == '雲端') subCat = 'iCloud/Google Drive';
    if (s == 'disney' || s == 'disney+' || s == '迪士尼') subCat = 'Disney+';
    if (s == '遊戲' || s == '課金' || s == '遊戲儲值') subCat = '遊戲課金';
    if (s == '物品遺失' || s == '遺失重買' || s == '重買') subCat = '物品遺失重買';

    // 6. 家庭專屬
    if (s == '房屋稅' || s == '地價稅' || s == '繳稅') subCat = '房屋稅/地價稅';
    if (s == '尿布' || s == '奶粉') subCat = '尿布奶粉';
    if (s == '玩具' || s == '童書') subCat = '玩具/童書';
    if (s == '機票' || s == '住宿' || s == '訂房' || s == '飯店') subCat = '機票住宿';
    if (s == '長輩醫療' || s == '長輩看診') subCat = '長輩醫療';
    if (s == '全家出遊' || s == '出遊餐飲') subCat = '全家出遊餐飲';

    // 7. 收入 (預防萬一)
    if (s == '退稅' || s == '補助') subCat = '退稅/補助';

    // --- 翻譯蒟蒻結束 ---
    String comment = data['comment'] ?? "";
    String merchant = data['merchant'] ?? "";
    String itemsSummary = data['items_summary'] ?? "";
    String invoiceNum = data['invoice_number'] ?? "";
    String date = data['date'] ?? "";

    // ===== 暫存 AI 回傳內容：之後按下「確認」時會寫入 V2 記帳表（receipts / ai_notes / tags）=====
    try {
      _pendingAiJson = jsonEncode(resJson);
    } catch (_) {
      _pendingAiJson = null;
    }
    _pendingMerchant = merchant;
    _pendingItemsSummary = itemsSummary;
    _pendingInvoiceNumber = invoiceNum;
    _pendingSuggestedSubCategory = subCat;
    _pendingAiModel = (data['model'] ?? resJson['model'] ?? '').toString();

    final confRaw = data['confidence'] ?? data['ai_confidence'];
    _pendingAiConfidence = confRaw is num ? confRaw.toDouble() : double.tryParse(confRaw?.toString() ?? '');

    // date 可能是 yyyy-MM-dd / yyyy/MM/dd / ISO
    DateTime? parsedOccurredAt;
    if (date.trim().isNotEmpty) {
      try {
        parsedOccurredAt = DateTime.parse(date.trim());
      } catch (_) {
        final m = RegExp(r'^(\d{4})[\/-](\d{1,2})[\/-](\d{1,2})').firstMatch(date.trim());
        if (m != null) {
          final y = int.tryParse(m.group(1)!);
          final mo = int.tryParse(m.group(2)!);
          final d = int.tryParse(m.group(3)!);
          if (y != null && mo != null && d != null) {
            parsedOccurredAt = DateTime(y, mo, d);
          }
        }
      }
    }
    _pendingOccurredAt = parsedOccurredAt;

    // tags
    final rawTags = data['tags'] ?? [];
    if (rawTags is List) {
      _pendingTags = rawTags.map((e) => e.toString()).toList();
    } else {
      _pendingTags = [];
    }

    List<dynamic> tagsList = data['tags'] ?? [];
    String tagsStr = tagsList.join(" ");
    if (tagsStr.isNotEmpty) {
      tagsStr = "🔍 $tagsStr";
    }

    String displayNote = "";
    if (merchant.isNotEmpty && !merchant.contains("未知")) {
      displayNote += "【$merchant】\n";
    }
    if (itemsSummary.isNotEmpty) {
      displayNote += "🛒 $itemsSummary\n";
    }
    if (tagsStr.isNotEmpty) {
      displayNote += "$tagsStr\n";
    }
    if (invoiceNum.isNotEmpty) displayNote += "🧾 $invoiceNum ($date)";

    // ★★★ 核心修改：判斷是不是收入，呼叫不同的彈窗 ★★★
    List<String> incomeMainCategories = ["薪水", "投資收益", "禮金", "其他收入", "零用錢", "打工收入", "獎學金", "投資獲利", "被動收入", "退稅/補助"];
    bool isIncome = incomeMainCategories.contains(mainCat) || mainCat == '收入' || subCat.contains('薪水') || subCat.contains('退稅');

    // 設定頁的「AI 分類建議」關閉時：保留 AI 抓到的金額、商家與備註，但分類交給使用者手動確認。
    if (!_useAiSuggestion) {
      mainCat = isIncome ? '其他收入' : '其他支出';
      subCat = isIncome ? '退款' : '其他';
      _pendingSuggestedSubCategory = null;
    }

    if (mounted) {
      if (isIncome) {
        // 防呆校正：就算後端主分類偷懶，我們也幫它強制冠上一個預設收入類別
        if (mainCat.isEmpty || mainCat == '其他支出' || mainCat == '收入') mainCat = '其他收入';
        _showIncomeConfirmationDialog(amount, subCat, mainCat, displayNote.trim(), comment);
      } else {
        _showConfirmationDialog(amount, subCat, mainCat, displayNote.trim(), comment);
      }
    }
  }

  void _showErrorSnackBar(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(msg), backgroundColor: Colors.red),
    );
  }

  // ★★★ 原本的確認視窗 (負責處理支出) ★★★
  void _showConfirmationDialog(double initAmount, String initSub, String initMain, String initNote, String aiComment) {
    final amountController = TextEditingController(text: initAmount.toStringAsFixed(0));
    final noteController = TextEditingController(text: initNote);

    String selectedMain = initMain;
    String selectedSub = initSub;

    // 支出清單的所有主分類
    List<String> expenseMains = ["飲食", "交通", "生活用品", "社交", "娛樂", "通訊網路", "服飾美容", "醫療健康", "住房", "其他支出", "學費與教材", "線上訂閱", "小確幸", "禮物與送禮", "不見了", "投資理財", "家具家電", "房貸與修繕", "小孩教育", "保險費用", "長輩支出", "家庭旅遊"];

    // 1. 如果 AI 給的主分類不在我們的清單裡，歸類到「其他支出」
    if (!expenseMains.contains(selectedMain)) {
      selectedMain = "其他支出";
    }

    showDialog(
      context: context,
      builder: (ctx) {
        return StatefulBuilder(
            builder: (context, setStateDialog) {

              // 根據身份過濾主分類 (排除收入類別)
              List<String> validMainCategories = [];
              _categoryData.forEach((key, value) {
                if (!expenseMains.contains(key)) return; // 只顯示支出

                String group = value['group'];
                bool show = false;
                if (group == 'all') show = true;
                else if (_userIdentity == 'u23' && group == 'student') show = true;
                else if (_userIdentity == 'a23_35' && group == 'worker') show = true;
                else if (_userIdentity == 'a35p' && group == 'family') show = true;

                if (show) validMainCategories.add(key);
              });

              if (!validMainCategories.contains(selectedMain) && validMainCategories.isNotEmpty) {
                selectedMain = validMainCategories[0];
                selectedSub = (_categoryData[selectedMain]?["subs"] as List)[0];
              }

              List<String> currentSubList = List<String>.from(_categoryData[selectedMain]?["subs"] ?? []);

              // ★★★ 如果 AI 的子分類 (例如 "飲料/咖啡") 在清單裡，就直接選中 ★★★
              // 如果不在清單裡 (AI自創)，就暫時加進去，並選中
              if (!currentSubList.contains(selectedSub)) {
                currentSubList.insert(0, selectedSub);
              } else {
                currentSubList.remove(selectedSub);
                currentSubList.insert(0, selectedSub);
              }

              return AlertDialog(
                title: const Text("✨ AI 分析結果確認"),
                content: SingleChildScrollView(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text("分類", style: TextStyle(fontSize: 12, color: Colors.grey)),
                      const SizedBox(height: 8),

                      Row(
                        children: [
                          // 左邊：主分類 Dropdown
                          Expanded(
                            child: DropdownButtonFormField<String>(
                              value: selectedMain,
                              isExpanded: true,
                              decoration: const InputDecoration(
                                labelText: '主分類',
                                border: OutlineInputBorder(),
                                contentPadding: EdgeInsets.symmetric(horizontal: 10, vertical: 8),
                              ),
                              items: validMainCategories.map((String value) {
                                return DropdownMenuItem<String>(
                                  value: value,
                                  child: Text(value, style: const TextStyle(fontSize: 14)),
                                );
                              }).toList(),
                              onChanged: (String? newValue) {
                                if (newValue != null) {
                                  setStateDialog(() {
                                    selectedMain = newValue;
                                    selectedSub = (_categoryData[selectedMain]?["subs"] as List)[0];
                                  });
                                }
                              },
                            ),
                          ),
                          const SizedBox(width: 10),
                          // 右邊：子分類 Dropdown
                          Expanded(
                            child: DropdownButtonFormField<String>(
                              value: selectedSub,
                              isExpanded: true,
                              decoration: const InputDecoration(
                                labelText: '子分類',
                                border: OutlineInputBorder(),
                                contentPadding: EdgeInsets.symmetric(horizontal: 10, vertical: 8),
                              ),
                              items: currentSubList.map((String value) {
                                return DropdownMenuItem<String>(
                                  value: value,
                                  child: Text(value, style: const TextStyle(fontSize: 14)),
                                );
                              }).toList(),
                              onChanged: (String? newValue) {
                                if (newValue != null) {
                                  setStateDialog(() {
                                    selectedSub = newValue;
                                  });
                                }
                              },
                            ),
                          ),
                        ],
                      ),

                      const SizedBox(height: 16),

                      const Text("金額", style: TextStyle(fontSize: 12, color: Colors.grey)),
                      TextField(
                        controller: amountController,
                        keyboardType: TextInputType.number,
                        decoration: const InputDecoration(prefixText: "\$ "),
                        style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                      ),
                      const SizedBox(height: 16),

                      const Text("備註", style: TextStyle(fontSize: 12, color: Colors.grey)),
                      TextField(
                        controller: noteController,
                        maxLines: 4,
                        decoration: const InputDecoration(border: OutlineInputBorder()),
                      ),
                    ],
                  ),
                ),
                actions: [
                  TextButton(
                    onPressed: () => Navigator.of(ctx).pop(),
                    child: const Text("取消"),
                  ),
                  ElevatedButton(
                    onPressed: () {
                      final finalAmount = double.tryParse(amountController.text) ?? initAmount;
                      final finalNote = noteController.text;
                      Navigator.of(ctx).pop();
                      _saveAIResult(finalAmount, selectedSub, selectedMain, finalNote, aiComment); // 預設是支出
                    },
                    style: ElevatedButton.styleFrom(backgroundColor: Colors.black, foregroundColor: Colors.white),
                    child: const Text("確認儲存"),
                  ),
                ],
              );
            }
        );
      },
    );
  }

  // ★★★ 全新設計：專屬收入的確認視窗 (支援動態主分類) ★★★
  void _showIncomeConfirmationDialog(double initAmount, String initSub, String initMain, String initNote, String aiComment) {
    final amountController = TextEditingController(text: initAmount.toStringAsFixed(0));
    final noteController = TextEditingController(text: initNote);

    String selectedMain = initMain;
    String selectedSub = initSub;

    // 收入清單的所有主分類
    List<String> incomeMains = ["薪水", "投資收益", "禮金", "其他收入", "零用錢", "打工收入", "獎學金", "投資獲利", "被動收入", "退稅/補助"];

    // 1. 如果 AI 給的主分類不在我們的清單裡，歸類到「其他收入」
    if (!incomeMains.contains(selectedMain)) {
      selectedMain = "其他收入";
    }

    showDialog(
      context: context,
      builder: (ctx) {
        return StatefulBuilder(
            builder: (context, setStateDialog) {

              // 根據身份過濾主分類 (只顯示收入類別)
              List<String> validIncomeCategories = [];
              _categoryData.forEach((key, value) {
                if (!incomeMains.contains(key)) return; // 只顯示收入

                String group = value['group'];
                bool show = false;
                if (group == 'all') show = true;
                else if (_userIdentity == 'u23' && group == 'student') show = true;
                else if (_userIdentity == 'a23_35' && group == 'worker') show = true;
                else if (_userIdentity == 'a35p' && group == 'family') show = true;

                if (show) validIncomeCategories.add(key);
              });

              if (!validIncomeCategories.contains(selectedMain) && validIncomeCategories.isNotEmpty) {
                // 如果目前的選擇不在過濾後的清單裡，優先選其他收入，沒有就選第一個
                selectedMain = validIncomeCategories.firstWhere((cat) => cat == "其他收入", orElse: () => validIncomeCategories[0]);
                selectedSub = (_categoryData[selectedMain]?["subs"] as List)[0];
              }

              List<String> currentSubList = List<String>.from(_categoryData[selectedMain]?["subs"] ?? []);

              // 如果 AI 自創的收入分類不在我們的清單裡，就暫時加進去
              if (!currentSubList.contains(selectedSub)) {
                if (selectedSub.trim().isEmpty) {
                  selectedSub = currentSubList[0];
                } else {
                  currentSubList.insert(0, selectedSub);
                }
              } else {
                currentSubList.remove(selectedSub);
                currentSubList.insert(0, selectedSub);
              }

              return AlertDialog(
                // 專屬綠色標題
                title: const Text("💰 收入進帳確認", style: TextStyle(color: Colors.green, fontWeight: FontWeight.bold)),
                content: SingleChildScrollView(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text("分類", style: TextStyle(fontSize: 12, color: Colors.grey)),
                      const SizedBox(height: 8),

                      Row(
                        children: [
                          // 左邊：主分類 Dropdown (只有過濾後的收入可以選)
                          Expanded(
                            child: DropdownButtonFormField<String>(
                              value: selectedMain,
                              isExpanded: true,
                              decoration: const InputDecoration(
                                labelText: '主分類',
                                border: OutlineInputBorder(),
                                contentPadding: EdgeInsets.symmetric(horizontal: 10, vertical: 8),
                              ),
                              items: validIncomeCategories.map((String value) {
                                return DropdownMenuItem<String>(
                                  value: value,
                                  child: Text(value, style: const TextStyle(fontSize: 14)),
                                );
                              }).toList(),
                              onChanged: (String? newValue) {
                                if (newValue != null) {
                                  setStateDialog(() {
                                    selectedMain = newValue;
                                    selectedSub = (_categoryData[selectedMain]?["subs"] as List)[0];
                                  });
                                }
                              },
                            ),
                          ),
                          const SizedBox(width: 10),
                          // 右邊：子分類 Dropdown
                          Expanded(
                            child: DropdownButtonFormField<String>(
                              value: selectedSub,
                              isExpanded: true,
                              decoration: const InputDecoration(
                                labelText: '子分類',
                                border: OutlineInputBorder(),
                                contentPadding: EdgeInsets.symmetric(horizontal: 10, vertical: 8),
                              ),
                              items: currentSubList.map((String value) {
                                return DropdownMenuItem<String>(
                                  value: value,
                                  child: Text(value, style: const TextStyle(fontSize: 14)),
                                );
                              }).toList(),
                              onChanged: (String? newValue) {
                                if (newValue != null) {
                                  setStateDialog(() {
                                    selectedSub = newValue;
                                  });
                                }
                              },
                            ),
                          ),
                        ],
                      ),

                      const SizedBox(height: 16),

                      const Text("金額", style: TextStyle(fontSize: 12, color: Colors.grey)),
                      TextField(
                        controller: amountController,
                        keyboardType: TextInputType.number,
                        // 加號提示這是一筆進帳
                        decoration: const InputDecoration(prefixText: "+ \$ "),
                        style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.green),
                      ),
                      const SizedBox(height: 16),

                      const Text("備註", style: TextStyle(fontSize: 12, color: Colors.grey)),
                      TextField(
                        controller: noteController,
                        maxLines: 4,
                        decoration: const InputDecoration(border: OutlineInputBorder()),
                      ),
                    ],
                  ),
                ),
                actions: [
                  TextButton(
                    onPressed: () => Navigator.of(ctx).pop(),
                    child: const Text("取消"),
                  ),
                  ElevatedButton(
                    onPressed: () {
                      final finalAmount = double.tryParse(amountController.text) ?? initAmount;
                      final finalNote = noteController.text;
                      Navigator.of(ctx).pop();
                      // ★★★ 關鍵：呼叫儲存時，加入 isIncome: true 參數 ★★★
                      _saveAIResult(finalAmount, selectedSub, selectedMain, finalNote, aiComment, isIncome: true);
                    },
                    style: ElevatedButton.styleFrom(backgroundColor: Colors.green, foregroundColor: Colors.white),
                    child: const Text("確認存入"),
                  ),
                ],
              );
            }
        );
      },
    );
  }

  // ★★★ AI 記帳 (加入 isIncome 判斷方向) ★★★

  Future<void> _saveAIResult(double amount, String subCat, String mainCat, String note, String aiComment, {bool isIncome = false}) async {
    try {
      // 根據我們從彈窗傳進來的狀態，決定資料庫寫入方向
      String dbType = isIncome ? 'income' : 'expense';

      // 1) --- 分類解鎖邏輯（沿用舊版） ---
      if (subCat.trim().isNotEmpty) {
        bool isDefaultCategory = false;

        // 檢查是否為「預設分類」 (因為現在 _categoryData 包含所有分類，直接掃描即可)
        _categoryData.forEach((key, value) {
          if ((value['subs'] as List).contains(subCat.trim())) {
            isDefaultCategory = true;
          }
        });

        // ★★★ 規則：AI 記帳，預設分類 -> 1次解鎖； 非預設(AI自創) -> 5次解鎖 ★★★
        int threshold = isDefaultCategory ? 1 : 5;
        // ★★★ 修正：預設分類解鎖「主類」，AI自創分類才解鎖「子類(視為主類)」 ★★★
        String unlockName = isDefaultCategory ? mainCat.trim() : subCat.trim();

        // ※ 這裡會自動：不存在就補一筆 categories（is_custom=1），並累加 usage_count
        await DatabaseHelper.instance.applyUnlockRuleForName(
          name: unlockName,
          type: dbType, // ★ 改用動態變數
          customUnlockThreshold: threshold,
        );
      }

      // 2) --- 寫入「V2 記帳表」(accounting_transactions / receipts / ai_notes / tags) ---
      final entry = _pendingEntryMethod ?? 'scan';
      final rawInput = _pendingRawInput;
      final tags = _pendingTags;

      await DatabaseHelper.instance.insertAiTransaction(
        amount: amount,
        direction: dbType, // ★ 改用動態變數，解決原本寫死 'expense' 的問題
        selectedMainCategory: mainCat,
        selectedSubCategory: subCat,
        suggestedSubCategory: _pendingSuggestedSubCategory,
        aiConfidence: _pendingAiConfidence,
        entryMethod: entry,
        captureMethod: entry,
        source: 'backend',
        merchantName: _pendingMerchant,
        note: note,
        occurredAt: DateTime.now(),
        rawInput: rawInput,
        parsedJson: _pendingAiJson,
        invoiceNumber: _pendingInvoiceNumber,
        aiModel: _pendingAiModel,
        aiShortComment: aiComment,
        aiItemsSummary: _pendingItemsSummary,
        tags: tags,
      );

      // 3) 重新讀取交易資料（避免 UI/DB 不同步）
      await _loadData();
      await _checkMonthlyBudgetAfterSave(isIncome: isIncome);

      // 4) 觸發動物講話 (沿用你的原本功能)
      if (aiComment.isNotEmpty && _selectedIndex == 1) {
        _homeKey.currentState?.triggerAiComment(aiComment);
      } else if (aiComment.isNotEmpty && _homeKey.currentState != null) {
        _homeKey.currentState!.showAiComment(aiComment);
      }

      // 5) 清掉暫存（避免下一筆沿用）
      _pendingAiJson = null;
      _pendingMerchant = null;
      _pendingItemsSummary = null;
      _pendingInvoiceNumber = null;
      _pendingAiConfidence = null;
      _pendingSuggestedSubCategory = null;
      _pendingAiModel = null;
      _pendingOccurredAt = null;
      _pendingTags = [];

      // 6) Snackbar
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(isIncome ? '✅ 收入已存入' : '✅ 記帳完成'),
            backgroundColor: Colors.green,
            duration: const Duration(milliseconds: 1500),
          ),
        );
      }
    } catch (e) {
      print("資料庫操作錯誤: $e");
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('❌ 記帳失敗：$e'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  IconData _mapCategoryToIcon(String mainCategory, [String subCategory = ""]) {
    bool isDefaultCategory = false;

    if (_categoryData.containsKey(mainCategory)) {
      final subs = List<String>.from(_categoryData[mainCategory]!['subs']);
      if (subs.contains(subCategory) || subCategory.isEmpty) {
        isDefaultCategory = true;
      }
    }

    if (!isDefaultCategory) {
      return Icons.more_horiz_rounded;
    }

    String key = "$mainCategory $subCategory";

    if (key.contains("食") || key.contains("餐") || key.contains("飲") || key.contains("零")) return Icons.fastfood_rounded;
    if (key.contains("衣") || key.contains("飾") || key.contains("鞋")) return Icons.checkroom_rounded;
    if (key.contains("行") || key.contains("交通") || key.contains("車") || key.contains("油")) return Icons.directions_bus_rounded;
    if (key.contains("育") || key.contains("學") || key.contains("書") || key.contains("課")) return Icons.school_rounded;
    if (key.contains("樂") || key.contains("娛") || key.contains("遊") || key.contains("影")) return Icons.sports_esports_rounded;
    if (key.contains("醫") || key.contains("藥") || key.contains("健")) return Icons.medical_services_rounded;
    if (key.contains("住") || key.contains("房") || key.contains("水電") || key.contains("瓦斯")) return Icons.home_rounded;
    if (key.contains("3C") || key.contains("電") || key.contains("機")) return Icons.devices_rounded;

    return Icons.receipt_long_rounded;
  }

  // ★★★ 手動記帳 (手動一律 1 次解鎖，觸發通關密語！) ★★★
  void _addTransaction(Transaction tx) async {
    // ★★★ 修正：如果是今天第一筆，只去後端拿台詞，不要彈出確認視窗覆蓋分類！ ★★★
    if (_isFirstTransactionToday) {
      setState(() {
        _isAnalyzing = true;
        _pendingEntryMethod = 'manual';
      });

      String aiComment = "汪！早安主人！今天的第一筆帳，狗狗幫你旺旺開張！";

      try {
        final token = await _getAuthToken(); // ★ 1. 拿出 Token
        final url = Uri.parse('${BackendConfig.baseUrl}/classify');
        final now = DateTime.now();
        String timeStr = "${now.hour.toString().padLeft(2, '0')}:${now.minute.toString().padLeft(2, '0')}";

        final response = await http.post(
          url,
          headers: {
            "Content-Type": "application/json",
            if (token != null) "Authorization": "Bearer $token", // ★ 2. 夾在 Header 送出
          },
          body: jsonEncode({
            "scanned_content": "",
            "user_input": "手動記帳：買了${tx.category}，花了${tx.amount}元。備註：${tx.note}",
            "identity": _userIdentity,
            "current_time": timeStr
          }),
        ).timeout(const Duration(seconds: 15));

        if (response.statusCode == 200) {
          final resJson = jsonDecode(response.body);
          if (resJson['data'] != null && resJson['data']['comment'] != null) {
            aiComment = resJson['data']['comment'];
          }
        }
      } catch (e) {
        print("Manual AI Error: $e");
      }

      if (mounted) {
        setState(() {
          _isAnalyzing = false;
        });
      }

      // ★★★ 關鍵修正：直接存入使用者原本選好的 tx，完全不理會 AI 猜的分類！ ★★★
      await DatabaseHelper.instance.insertTransaction(tx);

      final name = tx.category.trim();
      if (name.isNotEmpty) {
        final dbType = tx.type == TransactionType.expense ? 'expense' : 'income';

        // ★★★ 修正：判斷手動記帳的分類是「預設子類」還是「自創分類」 ★★★
        bool isDefaultCategory = false;
        String foundMainCategory = name; // 預設用自己當主類

        _categoryData.forEach((key, value) {
          if ((value['subs'] as List).contains(name)) {
            isDefaultCategory = true;
            foundMainCategory = key; // 找到對應的老大 (例如: 飲食)
          }
        });

        // 預設子類 -> 解鎖老大(foundMainCategory)
        // 自創分類 -> 解鎖自己(name)
        String unlockName = isDefaultCategory ? foundMainCategory : name;

        await DatabaseHelper.instance.applyUnlockRuleForName(
          name: unlockName,
          type: dbType,
          customUnlockThreshold: 1,
          isUserCreated: !isDefaultCategory, // 只有非預設才是真正自創
        );
      }

      await _loadData();
      await _checkMonthlyBudgetAfterSave(isIncome: tx.type == TransactionType.income);

      // 在首頁直接秀出這句剛向 AI 要來的台詞
      String commentToShow = tx.note.isNotEmpty ? "${tx.note}\n$aiComment" : aiComment;
      if (_selectedIndex == 1) {
        _homeKey.currentState?.triggerAiComment(commentToShow);
      }
      return;
    }

    // 1. 寫入資料庫
    await DatabaseHelper.instance.insertTransaction(tx);

    // ★★★ 規則：手動記帳，觸發 isUserCreated: true，一律 1 次解鎖！★★★
    final name = tx.category.trim();
    if (name.isNotEmpty) {
      final dbType = tx.type == TransactionType.expense ? 'expense' : 'income';

      // ★★★ 修正：判斷手動記帳的分類是「預設子類」還是「自創分類」 ★★★
      bool isDefaultCategory = false;
      String foundMainCategory = name; // 預設用自己當主類

      _categoryData.forEach((key, value) {
        if ((value['subs'] as List).contains(name)) {
          isDefaultCategory = true;
          foundMainCategory = key; // 找到對應的老大 (例如: 飲食)
        }
      });

      // 預設子類 -> 解鎖老大(foundMainCategory)
      // 自創分類 -> 解鎖自己(name)
      String unlockName = isDefaultCategory ? foundMainCategory : name;

      await DatabaseHelper.instance.applyUnlockRuleForName(
        name: unlockName,
        type: dbType,
        customUnlockThreshold: 1,
        isUserCreated: !isDefaultCategory, // 只有非預設才是真正自創
      );
    }

    // 2. 重新讀取資料庫，確保 UI 同步 (加入朋友的防呆)
    await _loadData();
    await _checkMonthlyBudgetAfterSave(isIncome: tx.type == TransactionType.income);

    // 3. 準備動物要講的話 (本地金句)
    String localQuote = LocalAiService.getRandomComment(tx.category);
    String commentToShow = "";

    if (tx.note.isNotEmpty) {
      commentToShow = "${tx.note}\n$localQuote";
    } else {
      commentToShow = localQuote;
    }

    // 4. 觸發動物講話
    if (_selectedIndex == 1) {
      _homeKey.currentState?.triggerAiComment(commentToShow);
    }
  }

  // ★★★ 新增：處理刪除交易紀錄 (滑動刪除) ★★★
  Future<void> _deleteTransaction(String id) async {
    // ★ 解開註解：正式從資料庫刪除
    await DatabaseHelper.instance.deleteTransaction(int.parse(id));

    // 暫時先在畫面上移除，讓你立刻看到左滑刪除的效果
    setState(() {
      _transactions.removeWhere((tx) => tx.id == id);
    });
  }

  // ★★★ 新增：處理編輯交易紀錄 (滑動編輯) ★★★
  void _editTransaction(Transaction tx) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (_) {
        return NewTransactionSheet(
          // ★ 解開註解：把舊資料傳入表單
          initialTransaction: tx,
          onAddTransaction: (updatedTx) async {
            // ★ 解開註解：呼叫更新並重新載入資料
            await DatabaseHelper.instance.updateTransaction(updatedTx);
            await _loadData();
          },
        );
      },
    );
  }

  void _onItemTapped(int index) {
    _loadRuntimeSettings();
    setState(() {
      _selectedIndex = index;
    });
  }

  void _openAddTransactionSheet() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (_) {
        return NewTransactionSheet(onAddTransaction: _addTransaction);
      },
    );
  }

  void _navigateToPage(Widget page) {
    Navigator.of(context).push(
      MaterialPageRoute(builder: (context) => page),
    );
  }

  // ★★★ 新增：條件判斷觸發特定寵物動畫與文字 ★★★
  Map<String, String> _getPetAnimationConfig() {
    // ★★★ 最高優先級：每日第一筆開張大吉 ★★★
    if (_isFirstTransactionToday) {
      return {
        'asset': 'assets/animations/Dog.json',
        'text': '早安主人！今天第一筆帳狗狗幫你開張！'
      };
    }

    // 優先級 2：深夜時段 23:00~04:59 (貓咪)
    final hour = DateTime.now().hour;
    if (hour >= 23 || hour < 5) {
      return {
        'asset': 'assets/animations/Cat.json',
        'text': '這麼晚還在花錢，本喵勉為其難幫你記著。'
      };
    }

    // ★★★ 優先級 3 與 4 修正：靠 [MODE] 標籤百分百精準判斷 ★★★
    if (_pendingEntryMethod == 'scan') {
      // 如果回傳的字串包含 E_INVOICE_QR，代表它沒有呼叫 OCR，是直接抓出條碼的狐狸
      if (_pendingRawInput != null && _pendingRawInput!.contains('[MODE] E_INVOICE_QR')) {
        return {
          'asset': 'assets/animations/Fox.json',
          'text': '呵呵，這種簡單的條碼，你的錢包沒有秘密...'
        };
      } else {
        // 否則，不管是傳統還是電子，只要是被相機 "拍照" (回傳了明細長文字)，就是樹懶
        return {
          'asset': 'assets/animations/Sloth.json',
          'text': '這張明細好複雜...慢慢算...'
        };
      }
    }

    // 優先級 5：語音輸入統一 (鸚鵡)
    if (_pendingEntryMethod == 'voice') {
      return {
        'asset': 'assets/animations/Parrot.json',
        'text': '聽到了！正在幫你翻譯成帳單...'
      };
    }

    // 防呆預設值
    return {
      'asset': 'assets/animations/Dog.json',
      'text': '寵物幫你算錢中，請稍候...'
    };
  }

  @override
  Widget build(BuildContext context) {
    final scanLabel = '掃描（${_scanMode == ScanMode.auto ? '自動' : '傳統'}）';

    return Stack(
      children: [
        Scaffold(
          body: IndexedStack(
            index: _selectedIndex,
            children: [
              const PlaygroundPage(),
              // ★★★ 把剛寫好的回呼函式接上 HomePage ★★★
              HomePage(
                key: _homeKey,
                transactions: _transactions,
                onAiAnalyzeRequest: _handleVoiceAnalysis,
                onDeleteTransaction: _deleteTransaction,
                onEditTransaction: _editTransaction,
              ),
              const SettingPage(),
            ],
          ),

          bottomNavigationBar: Container(
            padding: const EdgeInsets.only(bottom: 16.0, top: 8.0),
            decoration: BoxDecoration(
              color: Colors.white,
              boxShadow: [
                BoxShadow(
                  color: Colors.grey.withOpacity(0.2),
                  spreadRadius: 2,
                  blurRadius: 8,
                  offset: const Offset(0, -3),
                ),
              ],
              borderRadius: const BorderRadius.only(
                topLeft: Radius.circular(20),
                topRight: Radius.circular(20),
              ),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    _buildActionButton(Icons.add_circle, '記帳', _openAddTransactionSheet),
                    _buildActionButton(Icons.mic, '語音', _onVoiceBtnPressed),
                    _buildActionButton(Icons.qr_code_scanner, scanLabel, _goScan),
                  ],
                ),
                const SizedBox(height: 8),

                BottomNavigationBar(
                  items: const <BottomNavigationBarItem>[
                    BottomNavigationBarItem(
                      icon: Icon(Icons.play_arrow_rounded),
                      label: 'Playground',
                    ),
                    BottomNavigationBarItem(
                      icon: Icon(Icons.home_rounded),
                      label: 'Home',
                    ),
                    BottomNavigationBarItem(
                      icon: Icon(Icons.settings_rounded),
                      label: 'Settings',
                    ),
                  ],
                  currentIndex: _selectedIndex,
                  selectedItemColor: const Color(0xFFFF8FAB),
                  unselectedItemColor: Colors.grey.shade400,
                  onTap: _onItemTapped,
                  backgroundColor: Colors.transparent,
                  elevation: 0,
                  type: BottomNavigationBarType.fixed,
                ),
              ],
            ),
          ),
        ),

        // ★★★ 呼叫你原本超可愛的餵食動畫 Overlay ★★★
        if (_isAnalyzing)
          Builder(
              builder: (context) {
                // 在這裡呼叫我們新寫的判斷邏輯
                final animConfig = _getPetAnimationConfig();
                return Container(
                  color: Colors.black.withOpacity(0.85), // 深色半透明遮罩
                  child: Center(
                    child: _FeedingAnimationOverlay(
                      lottieAsset: animConfig['asset']!,
                      invoiceAsset: _invoiceIconPath,
                      loadingText: animConfig['text']!, // 傳入動態文字
                    ),
                  ),
                );
              }
          ),
      ],
    );
  }

  Widget _buildActionButton(IconData icon, String label, VoidCallback onPressed) {
    return InkWell(
      onTap: onPressed,
      borderRadius: BorderRadius.circular(30),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 46, height: 46,
              decoration: BoxDecoration(
                color: const Color(0xFFFFE4EE),
                shape: BoxShape.circle,
                border: Border.all(color: const Color(0xFFFF8FAB).withOpacity(0.5), width: 1.5),
              ),
              child: Icon(icon, size: 24, color: const Color(0xFFFF8FAB)),
            ),
            const SizedBox(height: 4),
            Text(label, style: const TextStyle(fontSize: 12, color: Color(0xFFFF8FAB), fontWeight: FontWeight.w600)),
          ],
        ),
      ),
    );
  }
}

// ==============================================================
// ★★★ 保留你的：循環播放發票飛入的動畫 Overlay ★★★
// ==============================================================
class _FeedingAnimationOverlay extends StatefulWidget {
  final String lottieAsset;
  final String invoiceAsset;
  final String loadingText; // ★★★ 新增：接收動態文字 ★★★

  const _FeedingAnimationOverlay({
    required this.lottieAsset,
    required this.invoiceAsset,
    required this.loadingText, // ★★★ 新增：接收動態文字 ★★★
  });

  @override
  State<_FeedingAnimationOverlay> createState() => _FeedingAnimationOverlayState();
}

class _FeedingAnimationOverlayState extends State<_FeedingAnimationOverlay> with SingleTickerProviderStateMixin {
  late AnimationController _controller;

  @override
  void initState() {
    super.initState();
    // 設定動畫控制器，循環播放 (Duration 為發票飛一次的時間)
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2), // 2秒飛一次
    )..repeat(); // 讓它一直重複
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        SizedBox(
          width: 250,
          height: 250,
          child: Stack(
            alignment: Alignment.center,
            children: [
              // 1. 底層：Lottie 動物動畫
              if (widget.lottieAsset.isNotEmpty)
                Positioned.fill(
                  child: Lottie.asset(
                    widget.lottieAsset,
                    fit: BoxFit.contain,
                  ),
                )
              else
                const CircularProgressIndicator(color: Colors.white),

              // 2. 上層：循環飛入的發票
              AnimatedBuilder(
                animation: _controller,
                builder: (context, child) {
                  // 計算動畫值：從底端 (-100) 飛到嘴邊 (60)
                  // 使用 Curves.easeInOut 讓飛行更順暢
                  final curvedValue = Curves.easeInOut.transform(_controller.value);
                  final bottomPos = -100 + (160 * curvedValue);

                  // 在快要結束時 (0.8~1.0) 讓發票變透明，看起來像被吃掉
                  final opacity = _controller.value > 0.8 ? (1.0 - _controller.value) * 5 : 1.0;

                  return Positioned(
                    bottom: bottomPos,
                    child: Opacity(
                      opacity: opacity.clamp(0.0, 1.0),
                      child: child!,
                    ),
                  );
                },
                child: Image.asset(
                  widget.invoiceAsset,
                  width: 60,
                  height: 60,
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 16),
        // ★★★ 修正：改用 widget.loadingText 動態顯示文字，並置中縮小字體 ★★★
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20.0),
          child: Text(
            widget.loadingText,
            textAlign: TextAlign.center, // 讓多行文字置中，看起來更整齊
            style: const TextStyle(
              color: Colors.white,
              fontSize: 16, // 把字體從 18 縮小到 16
              fontWeight: FontWeight.bold,
              decoration: TextDecoration.none, // 關鍵：移除黃色底線
            ),
          ),
        ),
      ],
    );
  }
}