import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:intl/date_symbol_data_local.dart';

// 引入頁面
import 'main_app_shell.dart';
import 'pages/login_page.dart';
import 'widgets/app_lock_gate.dart';

// ★★★ 關鍵：必須引入掃描頁面，不然 App 找不到路 ★★★
import 'features/scan/unified_auto_scan_page_v2_yolo_modified.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  await initializeDateFormatting('zh_TW', null);

  final prefs = await SharedPreferences.getInstance();
  final bool isOnboarded = prefs.getBool('is_onboarded') ?? false;

  runApp(MyApp(
    startPage: isOnboarded ? const MainAppShell() : const LoginPage(),
    enableAppLock: isOnboarded,
  ));
}

class MyApp extends StatelessWidget {
  final Widget startPage;
  final bool enableAppLock;

  const MyApp({super.key, required this.startPage, required this.enableAppLock});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'AI 記帳',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFFFF8FAB),
          brightness: Brightness.light,
        ),
        useMaterial3: true,
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
          ),
        ),
        inputDecorationTheme: InputDecorationTheme(
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(14)),
        ),
      ),
      home: AppLockGate(
        enabledForThisStart: enableAppLock,
        child: startPage,
      ),

      // ★★★ 修正這裡：補齊所有的路由 ★★★
      routes: {
        '/home': (context) => const MainAppShell(),
        '/login': (context) => const LoginPage(),

        // 補回這兩行，按鈕才會動！
        '/scan': (context) => const UnifiedAutoScanPageV2(),
        '/scan/traditional': (context) => const UnifiedAutoScanPageV2(forceTraditional: true),
      },
    );
  }
}