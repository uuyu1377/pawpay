import 'dart:io' show Platform;

import 'package:dio/dio.dart';
import 'package:flutter/foundation.dart';
import 'package:user_interface/config/backend_config.dart';

/// 大富翁 / 寵物 / 好友功能的 MySQL API 服務。
///
/// App 不直接連 MySQL，而是透過 FastAPI：
/// Flutter -> /game/* API -> MySQL。
class GameApiService {
  GameApiService._();
  static final GameApiService instance = GameApiService._();

  static String get baseUrl {
    if (kIsWeb) return 'http://localhost:${BackendConfig.mysqlApiPort}';
    if (Platform.isAndroid) {
      if (BackendConfig.androidEmulator) {
        return 'http://10.0.2.2:${BackendConfig.mysqlApiPort}';
      }
      return BackendConfig.mysqlApiBaseUrl;
    }
    return 'http://localhost:${BackendConfig.mysqlApiPort}';
  }

  final Dio _dio = Dio(
    BaseOptions(
      connectTimeout: const Duration(seconds: 3),
      receiveTimeout: const Duration(seconds: 10),
      sendTimeout: const Duration(seconds: 10),
      headers: {'Content-Type': 'application/json'},
    ),
  );

  Future<Map<String, dynamic>> fetchGameState({
    int userId = 1,
    required String theme,
  }) async {
    final res = await _dio.get(
      '$baseUrl/game/state',
      queryParameters: {'user_id': userId, 'theme': theme},
    );
    return _asMap(res.data);
  }

  Future<void> updatePlayerState({
    int userId = 1,
    int localId = 0,
    required int money,
    required int pathStep,
    int jailTurns = 0,
    bool isBankrupt = false,
    required String theme,
  }) async {
    await _dio.put(
      '$baseUrl/game/player',
      data: {
        'user_id': userId,
        'local_id': localId,
        'money': money,
        'path_step': pathStep,
        'jail_turns': jailTurns,
        'is_bankrupt': isBankrupt,
        'theme': theme,
      },
    );
  }

  Future<void> updateBlockState({
    int userId = 1,
    required String theme,
    required int index,
    required String name,
    required int baseCost,
    required String blockType,
    required double positionDx,
    required double positionDy,
    required int level,
    int? ownerLocalId,
  }) async {
    await _dio.put(
      '$baseUrl/game/block',
      data: {
        'user_id': userId,
        'theme': theme,
        'index': index,
        'name': name,
        'base_cost': baseCost,
        'block_type': blockType,
        'position_dx': positionDx,
        'position_dy': positionDy,
        'level': level,
        'owner_local_id': ownerLocalId,
      },
    );
  }

  Future<void> addGameLog({
    int userId = 1,
    required String eventType,
    required String message,
  }) async {
    await _dio.post(
      '$baseUrl/game/logs',
      data: {'user_id': userId, 'event_type': eventType, 'message': message},
    );
  }

  Future<int> fetchPlayerMoney({int userId = 1}) async {
    final res = await _dio.get('$baseUrl/game/player', queryParameters: {'user_id': userId});
    final data = _asMap(res.data);
    return _asInt(data['money'], fallback: 0);
  }

  Future<List<Map<String, dynamic>>> fetchPets({int userId = 1}) async {
    final res = await _dio.get('$baseUrl/game/pets', queryParameters: {'user_id': userId});
    return _asListOfMaps(res.data);
  }

  Future<Map<String, dynamic>> feedPet({
    int userId = 1,
    required int petId,
    required String foodName,
    required int price,
    required double gain,
    bool isMystery = false,
  }) async {
    final res = await _dio.post(
      '$baseUrl/game/pets/$petId/feed',
      data: {
        'user_id': userId,
        'food_name': foodName,
        'price': price,
        'gain': gain,
        'is_mystery': isMystery,
      },
    );
    return _asMap(res.data);
  }

  Future<Map<String, dynamic>> gachaDraw({int userId = 1, int cost = 100}) async {
    final res = await _dio.post('$baseUrl/game/gacha/draw', data: {'user_id': userId, 'cost': cost});
    return _asMap(res.data);
  }

  Future<List<Map<String, dynamic>>> fetchFriends({int userId = 1}) async {
    final res = await _dio.get('$baseUrl/game/friends', queryParameters: {'user_id': userId});
    return _asListOfMaps(res.data);
  }

  Future<List<Map<String, dynamic>>> fetchRecommendedFriends({int userId = 1}) async {
    final res = await _dio.get('$baseUrl/game/friends/recommended', queryParameters: {'user_id': userId});
    return _asListOfMaps(res.data);
  }

  Future<List<Map<String, dynamic>>> searchUsers({int userId = 1, required String query}) async {
    final res = await _dio.get('$baseUrl/game/users/search', queryParameters: {'user_id': userId, 'q': query});
    return _asListOfMaps(res.data);
  }

  Future<void> addFriend({int userId = 1, required int friendId}) async {
    await _dio.post('$baseUrl/game/friends', data: {'user_id': userId, 'friend_id': friendId});
  }

  Future<Map<String, dynamic>> fetchMonsterStatus({int userId = 1}) async {
    final res = await _dio.get('$baseUrl/game/monster/status', queryParameters: {'user_id': userId});
    return _asMap(res.data);
  }

  Future<Map<String, dynamic>> attackMonster({int userId = 1}) async {
    final res = await _dio.post('$baseUrl/game/monster/attack', data: {'user_id': userId});
    return _asMap(res.data);
  }

  Map<String, dynamic> _asMap(dynamic data) {
    if (data is Map) return Map<String, dynamic>.from(data);
    return <String, dynamic>{};
  }

  List<Map<String, dynamic>> _asListOfMaps(dynamic data) {
    if (data is! List) return <Map<String, dynamic>>[];
    return data.whereType<Map>().map((e) => Map<String, dynamic>.from(e)).toList();
  }

  int _asInt(dynamic value, {int fallback = 0}) {
    if (value is int) return value;
    if (value is num) return value.toInt();
    return int.tryParse(value?.toString() ?? '') ?? fallback;
  }
}
